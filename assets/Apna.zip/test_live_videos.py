import aiohttp
import asyncio
import re

async def get_store_token(session, org_code):
    url = f"https://{org_code}.courses.store"
    async with session.get(url) as response:
        text = await response.text()
        match = re.search(r'"hash":"(.*?)"', text)
        return match.group(1) if match else None

async def get_first_batch(session, token):
    url = f"https://api.classplusapp.com/v2/course/preview/similar/{token}"
    headers = {
        "api-version": "35",
        "app-version": "1.4.73.2",
        "device-id": "scanner_bot",
        "region": "IN",
    }
    async with session.get(url, headers=headers) as response:
        data = await response.json()
        batches = data.get("data", {}).get("coursesData", [])
        return batches[0] if batches else None

async def test_live_videos(org_code):
    async with aiohttp.ClientSession() as session:
        print(f"1. Getting token for {org_code}...")
        token = await get_store_token(session, org_code)
        if not token:
            print("Failed to get token")
            return

        print(f"2. Getting first batch...")
        batch = await get_first_batch(session, token)
        if not batch:
            print("No batches found")
            return
            
        course_id = batch['id']
        print(f"Testing with Batch: {batch['name']} (ID: {course_id})")

        # Test the endpoint
        url = "https://api.classplusapp.com/v2/course/live/list/videos"
        params = {
            "courseId": course_id,
            "limit": 10,
            "offset": 0
        }
        headers = {
            "api-version": "35",
            "app-version": "1.4.73.2",
            "device-id": "scanner_bot",
            "region": "IN",
            # Try with and without store token header if needed
            "tutorWebsiteDomain": f"https://{org_code}.courses.store" 
        }

        print(f"3. Calling {url}...")
        async with session.get(url, params=params, headers=headers) as resp:
            print(f"Status: {resp.status}")
            print(f"Response: {await resp.text()}")

if __name__ == "__main__":
    # Use a known valid org
    asyncio.run(test_live_videos("kalyan"))
