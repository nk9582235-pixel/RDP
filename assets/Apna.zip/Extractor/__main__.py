import asyncio
import importlib
import signal
import sys
from pyrogram import idle
from pyrogram.types import BotCommand
from Extractor.modules import ALL_MODULES

loop = asyncio.get_event_loop()

# Graceful shutdown
should_exit = asyncio.Event()

def shutdown():
    print("Shutting down gracefully...")
    should_exit.set()  # triggers exit from idle

# Handle SIGTERM and SIGINT
def signal_handler(signum, frame):
    print(f"Received signal {signum}, shutting down...")
    shutdown()

signal.signal(signal.SIGTERM, signal_handler)
signal.signal(signal.SIGINT, signal_handler)

async def sumit_boot():
    # Import the apps and global variables from __init__
    from Extractor import apps
    import Extractor
    
    # Define commands - ONLY scan_status is active
    commands = [
        BotCommand("scan_status", "Check Scanner Status"),
    ]

    # Start all bots and set commands
    for client in apps:
        await client.start()
        try:
            await client.set_bot_commands(commands)
            print(f"Set commands for client: {client.name}")
        except Exception as e:
            print(f"Failed to set commands for {client.name}: {e}")
        print(f"Started client: {client.name}")
    
    # Fetch bot info from the first bot (primary) and set global variables
    app = apps[0]
    getme = await app.get_me()
    Extractor.BOT_ID = getme.id
    Extractor.BOT_USERNAME = getme.username
    if getme.last_name:
        Extractor.BOT_NAME = getme.first_name + " " + getme.last_name
    else:
        Extractor.BOT_NAME = getme.first_name
    
    print(f"Bot started as {Extractor.BOT_NAME} (@{Extractor.BOT_USERNAME})")
    
    # Now load all modules
    for all_module in ALL_MODULES:
        importlib.import_module("Extractor.modules." + all_module)

    print("» ʙᴏᴛ ᴅᴇᴘʟᴏʏ sᴜᴄᴄᴇssғᴜʟʟʏ ✨ 🎉")
    
    # Auto-start scanner for continuous operation
    print("\n[AUTO-START] Initializing auto-scanner...")
    from Extractor.modules.scan import scan_state, scanner_loop
    from config import SCANNER_LOG_CHANNEL
    
    # Load progress from MongoDB database first
    await scan_state.load()
    
    # Check if scanner should resume from previous state
    if scan_state.current_code and scan_state.current_code != "aa":
        print(f"[AUTO-START] Resuming scan from saved position: {scan_state.current_code}")
        print(f"[AUTO-START] Previously scanned: {scan_state.scanned_count} codes")
        print(f"[AUTO-START] Previously found: {len(scan_state.found_orgs)} orgs")
    else:
        print("[AUTO-START] Starting fresh scan from: aa")
    
    scan_state.is_scanning = True
    
    # Create a dummy message object for scanner_loop
    class DummyMessage:
        def __init__(self):
            self.chat = type('obj', (object,), {'id': SCANNER_LOG_CHANNEL})()
    
    dummy_msg = DummyMessage()
    
    # Start scanner in background
    asyncio.create_task(scanner_loop(app, dummy_msg))
    print("[AUTO-START] ✅ Scanner started successfully! Bot will scan continuously.")
    print("[AUTO-START] Progress is saved to MongoDB every 500 codes.\n")
    
    await idle()  # keeps the bot alive

    print("» ɢᴏᴏᴅ ʙʏᴇ ! sᴛᴏᴘᴘɪɴɢ ʙᴏᴛ.")

if __name__ == "__main__":
    try:
        loop.run_until_complete(sumit_boot())
    except KeyboardInterrupt:
        print("Interrupted by user.")
    except Exception as e:
        print(f"Unexpected error: {e}")
        sys.exit(1)
    finally:
        # Cancel pending tasks to avoid "destroyed but pending" error
        pending = asyncio.all_tasks(loop)
        for task in pending:
            task.cancel()
        try:
            loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        except:
            pass
        loop.close()
        print("Loop closed.")