import os
import sys

# Mock os.environ if needed, or just let it read from system
# We want to see what config.py produces

try:
    import config
    print(f"BOT_TOKEN raw: {config.BOT_TOKEN}")
    print(f"BOT_TOKENS list: {config.BOT_TOKENS}")
    print(f"Number of tokens: {len(config.BOT_TOKENS)}")
except Exception as e:
    print(f"Error importing config: {e}")
