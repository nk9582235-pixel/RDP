import aiohttp
import asyncio

async def test_store_endpoints(org_code):
    # Endpoint 1: Store Course List (Public?)
    url1 = f"https://api.classplusapp.com/store/course/list?orgId={org_code}" # Guessing
    
    # Endpoint 2: Store Home (Public?)
    url2 = f"https://api.classplusapp.com/store/home?orgId={org_code}"
    
    headers = {
        'user-agent': 'Mobile-Android',
        'app-version': '1.4.65.3',
        'api-version': '29',
        'device-id': '39F093FF35F201D9',
    }
    
    async with aiohttp.ClientSession() as session:
        print(f"Testing {url1}...")
        async with session.get(url1, headers=headers) as resp:
            print(f"Status: {resp.status}")
            # print(f"Response: {await resp.text()}")
            
        print(f"\nTesting {url2}...")
        async with session.get(url2, headers=headers) as resp:
            print(f"Status: {resp.status}")
            # print(f"Response: {await resp.text()}")

if __name__ == "__main__":
    asyncio.run(test_store_endpoints("kalyan"))
