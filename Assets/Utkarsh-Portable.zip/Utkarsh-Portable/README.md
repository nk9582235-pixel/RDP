# Utkarsh Video Downloader - Portable Edition

A clean, portable video downloader for Utkarsh batch files.
Downloads videos directly to your local device.

## 📁 Folder Structure

```
Utkarsh-Portable/
├── DOWNLOAD.bat      ← Double-click to start
├── downloader.py     ← Main script
├── requirements.txt  ← Dependencies
├── Batch_XXXXX.txt   ← Your batch files (add here)
└── Downloads/        ← Downloaded videos go here
```

## 🚀 Quick Start

1. **Copy your batch files** (`Batch_*.txt`) to this folder
2. **Double-click `DOWNLOAD.bat`**
3. **Select batches** to download
4. **Wait** for downloads to complete

## ⚙️ Requirements

- Python 3.8+
- yt-dlp (auto-installed)
- aria2c (optional, for faster downloads)

## 📋 Features

- ✅ **Local-only** - No Google Drive needed
- ✅ **Parallel downloads** - Configurable (default: 3)
- ✅ **Skip existing** - Won't re-download files
- ✅ **Auto-retry** - Handles network errors
- ✅ **Progress logging** - See `download.log`
- ✅ **Portable** - Copy folder anywhere

## 🔧 Advanced Usage

Run directly with Python:
```bash
python downloader.py
```

## 📝 Notes

- Videos saved to `Downloads/<Course Name>/` folder
- PDFs are also downloaded
- Check `download.log` for errors
