"""
Utkarsh Video Downloader - Portable Local Version
Downloads videos from batch files to local folder
No Google Drive dependency - pure local download
"""

import os
import re
import sys
import time
import subprocess
import logging
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
import shutil
from tqdm import tqdm

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('download.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)

class VideoDownloader:
    def __init__(self, output_dir=r"E:\My Drive\Classplus (~1.2Tb)", parallel=3):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self.parallel = parallel
        self.progress_lock = Lock()
        self.success_count = 0
        self.fail_count = 0
        
    def parse_batch_file(self, batch_file):
        """Parse a batch file and extract courses with videos/PDFs"""
        sections = []
        current_section = None
        
        with open(batch_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                
                if line.startswith('Course:'):
                    if current_section:
                        sections.append(current_section)
                    
                    course_part = line.replace('Course:', '').strip()
                    course_name = re.sub(r'\s*\(ID:\s*\d+\)\s*$', '', course_part).strip()
                    # Clean folder name
                    course_name = re.sub(r'[<>:"/\\|?*]', '', course_name)
                    
                    current_section = {
                        'name': course_name,
                        'info': None,
                        'videos': [],
                        'pdfs': []
                    }
                
                elif line.startswith('Info:') and current_section:
                    current_section['info'] = line.replace('Info:', '').strip()
                
                elif ':http' in line:
                    parts = line.split(':http', 1)
                    if len(parts) == 2:
                        title = parts[0].strip()
                        title = re.sub(r'[<>:"/\\|?*]', '', title)  # Clean filename
                        url = 'http' + parts[1].strip()
                        
                        if '.pdf' in url.lower():
                            current_section['pdfs'].append((title, url))
                        else:
                            current_section['videos'].append((title, url))
        
        if current_section:
            sections.append(current_section)
        
        return sections
    
    def download_file(self, url, output_path, title):
        """Download a file using yt-dlp or aria2c"""
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        # Check if already exists
        expected_file = output_path.with_suffix('.mp4')
        if expected_file.exists() and expected_file.stat().st_size > 1000:
            logging.info(f"⏭️ Skipping (exists): {title}")
            return True
        
        # Also check for .ws files (converted to .mp4)
        for ext in ['.mp4', '.mkv', '.webm']:
            check_file = output_path.with_suffix(ext)
            if check_file.exists() and check_file.stat().st_size > 1000:
                logging.info(f"⏭️ Skipping (exists): {title}")
                return True
        
        try:
            # Use yt-dlp with aria2c
            cmd = [
                'yt-dlp',
                '--no-warnings',
                '-o', str(output_path.with_suffix('.%(ext)s')),
                '--external-downloader', 'aria2c',
                '--external-downloader-args', 'aria2c:-x8 -s8 -k5M --disable-ipv6=true --max-tries=10 --retry-wait=3 --quiet=true --console-log-level=error',
                '--no-playlist',
                '--retries', '5',
                '--fragment-retries', '5',
                url
            ]
            
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=600
            )
            
            if result.returncode == 0:
                logging.info(f"✅ Downloaded: {title}")
                return True
            else:
                # Fallback to yt-dlp without aria2c
                cmd_fallback = [
                    'yt-dlp',
                    '--no-warnings',
                    '-o', str(output_path.with_suffix('.%(ext)s')),
                    '--no-playlist',
                    '--retries', '10',
                    '--fragment-retries', '10',
                    url
                ]
                
                result = subprocess.run(cmd_fallback, capture_output=True, text=True, timeout=900)
                
                if result.returncode == 0:
                    logging.info(f"✅ Downloaded (fallback): {title}")
                    return True
                else:
                    logging.error(f"❌ Failed: {title} - {result.stderr[:200]}")
                    return False
                    
        except subprocess.TimeoutExpired:
            logging.error(f"❌ Timeout: {title}")
            return False
        except Exception as e:
            logging.error(f"❌ Error: {title} - {str(e)}")
            return False
    
    def download_pdf(self, url, output_path, title):
        """Download a PDF file"""
        output_path = Path(output_path).with_suffix('.pdf')
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if output_path.exists() and output_path.stat().st_size > 100:
            logging.info(f"⏭️ Skipping PDF (exists): {title}")
            return True
        
        try:
            import requests
            response = requests.get(url, timeout=60, stream=True)
            response.raise_for_status()
            
            with open(output_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    f.write(chunk)
            
            logging.info(f"📄 Downloaded PDF: {title}")
            return True
        except Exception as e:
            logging.error(f"❌ PDF Error: {title} - {str(e)}")
            return False
    
    def process_batch(self, batch_file):
        """Process a single batch file"""
        print("\n" + "=" * 80)
        print(f"📦 Processing: {batch_file}")
        print("=" * 80)
        
        sections = self.parse_batch_file(batch_file)
        
        if not sections:
            print("❌ No content found in batch file")
            return
        
        total_videos = sum(len(s['videos']) for s in sections)
        total_pdfs = sum(len(s['pdfs']) for s in sections)
        
        print(f"\n📊 Found {len(sections)} sections:")
        for i, section in enumerate(sections, 1):
            print(f"   [{i}] {section['name']}: {len(section['videos'])} videos, {len(section['pdfs'])} PDFs")
        
        print(f"\n🎬 Total: {total_videos} videos, {total_pdfs} PDFs")
        print()
        
        # Process each section
        for section in sections:
            section_dir = self.output_dir / section['name']
            
            # Add info subfolder if present
            if section['info']:
                section_dir = section_dir / re.sub(r'[<>:"/\\|?*]', '', section['info'])
            
            section_dir.mkdir(parents=True, exist_ok=True)
            
            print(f"\n📂 Section: {section['name']}")
            print(f"   📁 Output: {section_dir}")
            
            # Download videos in parallel
            if section['videos']:
                self._download_items(section['videos'], section_dir, is_video=True)
            
            # Download PDFs
            if section['pdfs']:
                self._download_items(section['pdfs'], section_dir, is_video=False)
    
    def _download_items(self, items, output_dir, is_video=True):
        """Download items in parallel with progress bar"""
        item_type = "videos" if is_video else "PDFs"
        
        with tqdm(total=len(items), desc=f"📥 {item_type}", unit="file", 
                  bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]') as pbar:
            
            with ThreadPoolExecutor(max_workers=self.parallel) as executor:
                futures = {}
                
                for idx, (title, url) in enumerate(items, 1):
                    # Create safe filename
                    safe_title = f"{idx:03d}_{title[:100]}"
                    output_path = output_dir / safe_title
                    
                    if is_video:
                        future = executor.submit(self.download_file, url, output_path, title)
                    else:
                        future = executor.submit(self.download_pdf, url, output_path, title)
                    
                    futures[future] = title
                
                # Wait for completion
                for future in as_completed(futures):
                    title = futures[future]
                    try:
                        success = future.result()
                        with self.progress_lock:
                            if success:
                                self.success_count += 1
                            else:
                                self.fail_count += 1
                    except Exception as e:
                        logging.error(f"❌ Exception: {title} - {str(e)}")
                        with self.progress_lock:
                            self.fail_count += 1
                    
                    pbar.update(1)

def main():
    print("=" * 80)
    print("🎓 UTKARSH VIDEO DOWNLOADER - Portable Local Version")
    print("=" * 80)
    print()
    
    # Check dependencies
    try:
        subprocess.run(['yt-dlp', '--version'], capture_output=True, check=True)
    except:
        print("❌ yt-dlp not found! Install with: pip install yt-dlp")
        sys.exit(1)
    
    # Find batch files
    batch_files = sorted(Path('.').glob('Batch_*.txt'))
    
    if not batch_files:
        print("❌ No Batch_*.txt files found in current directory")
        print("   Place your batch files in the same folder as this script")
        sys.exit(1)
    
    print(f"📁 Found {len(batch_files)} batch file(s)")
    for i, bf in enumerate(batch_files, 1):
        print(f"   [{i}] {bf.name}")
    
    print()
    
    # Get user selection
    selection = input("Enter batch numbers (e.g., 1,2,3) or 'all': ").strip()
    
    if selection.lower() == 'all':
        selected = batch_files
    else:
        try:
            indices = [int(x.strip()) - 1 for x in selection.split(',')]
            selected = [batch_files[i] for i in indices if 0 <= i < len(batch_files)]
        except:
            print("❌ Invalid selection")
            sys.exit(1)
    
    if not selected:
        print("❌ No batches selected")
        sys.exit(1)
    
    print(f"\n✅ Selected {len(selected)} batch(es)")
    
    # Get output directory
    default_output = r"E:\My Drive\Classplus (~1.2Tb)"
    output_dir = input(f"Output folder (Enter for default): ").strip() or default_output
    print(f"📁 Output: {output_dir}")
    
    # Get parallel downloads
    try:
        parallel = int(input("Parallel downloads (default: 3): ").strip() or "3")
    except:
        parallel = 3
    
    # Initialize downloader
    downloader = VideoDownloader(output_dir=output_dir, parallel=parallel)
    
    # Process each batch
    start_time = time.time()
    
    for batch_file in selected:
        downloader.process_batch(batch_file)
    
    # Summary
    elapsed = time.time() - start_time
    print("\n" + "=" * 80)
    print("📊 DOWNLOAD COMPLETE")
    print("=" * 80)
    print(f"   ✅ Success: {downloader.success_count}")
    print(f"   ❌ Failed: {downloader.fail_count}")
    print(f"   ⏱️ Time: {elapsed/60:.1f} minutes")
    print(f"   📁 Output: {downloader.output_dir.absolute()}")
    print("=" * 80)

if __name__ == "__main__":
    main()
