"""
Directory Scanner - Creates JSON inventory of downloaded files
Scans E:\My Drive\Classplus (~1.2Tb) and saves folder/file metadata
"""

import os
import json
from pathlib import Path
from datetime import datetime

def scan_directory(base_path):
    """Scan directory and return folder stats"""
    print("=" * 80)
    print("📂 DIRECTORY SCANNER")
    print("=" * 80)
    print(f"\nScanning: {base_path}")
    print()
    
    base = Path(base_path)
    
    if not base.exists():
        print(f"❌ Directory not found: {base_path}")
        return None
    
    results = {
        'scan_time': datetime.now().isoformat(),
        'base_path': str(base_path),
        'folders': {},
        'summary': {
            'total_folders': 0,
            'total_mp4': 0,
            'total_pdf': 0,
            'total_size_gb': 0
        }
    }
    
    # Scan each folder in base directory
    folders = sorted([f for f in base.iterdir() if f.is_dir()])
    total_folders = len(folders)
    
    for idx, folder in enumerate(folders, 1):
        folder_name = folder.name
        print(f"[{idx}/{total_folders}] {folder_name[:60]}...", end='\r')
        
        # Count files and calculate sizes
        mp4_files = list(folder.rglob('*.mp4'))
        pdf_files = list(folder.rglob('*.pdf'))
        
        mp4_count = len(mp4_files)
        pdf_count = len(pdf_files)
        
        # Calculate total size
        mp4_size = sum(f.stat().st_size for f in mp4_files if f.exists())
        pdf_size = sum(f.stat().st_size for f in pdf_files if f.exists())
        total_size = mp4_size + pdf_size
        
        # Get subfolders
        subfolders = {}
        for subfolder in folder.iterdir():
            if subfolder.is_dir():
                sub_mp4 = len(list(subfolder.rglob('*.mp4')))
                sub_pdf = len(list(subfolder.rglob('*.pdf')))
                sub_size = sum(f.stat().st_size for f in subfolder.rglob('*') if f.is_file())
                subfolders[subfolder.name] = {
                    'mp4_count': sub_mp4,
                    'pdf_count': sub_pdf,
                    'size_gb': round(sub_size / (1024**3), 2)
                }
        
        results['folders'][folder_name] = {
            'mp4_count': mp4_count,
            'pdf_count': pdf_count,
            'size_gb': round(total_size / (1024**3), 2),
            'subfolders': subfolders
        }
        
        results['summary']['total_mp4'] += mp4_count
        results['summary']['total_pdf'] += pdf_count
        results['summary']['total_size_gb'] += total_size / (1024**3)
    
    results['summary']['total_folders'] = len(folders)
    results['summary']['total_size_gb'] = round(results['summary']['total_size_gb'], 2)
    
    return results

def main():
    base_path = r"E:\My Drive\Classplus (~1.2Tb)"
    
    results = scan_directory(base_path)
    
    if results:
        # Save to JSON
        output_file = Path('folder_inventory.json')
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        
        print("\n" + "=" * 80)
        print("📊 SUMMARY")
        print("=" * 80)
        print(f"  📁 Total Folders: {results['summary']['total_folders']}")
        print(f"  🎬 Total MP4 Files: {results['summary']['total_mp4']}")
        print(f"  📄 Total PDF Files: {results['summary']['total_pdf']}")
        print(f"  💾 Total Size: {results['summary']['total_size_gb']:.1f} GB")
        print()
        print(f"💾 Saved to: {output_file.absolute()}")
        print()
        
        # Print top 10 folders by size
        print("=" * 80)
        print("📈 TOP 10 LARGEST FOLDERS")
        print("=" * 80)
        sorted_folders = sorted(
            results['folders'].items(), 
            key=lambda x: x[1]['size_gb'], 
            reverse=True
        )[:10]
        
        for name, data in sorted_folders:
            print(f"  {data['size_gb']:6.1f} GB | 🎬 {data['mp4_count']:4} | 📄 {data['pdf_count']:3} | {name[:50]}")
        
        print()

if __name__ == "__main__":
    main()
