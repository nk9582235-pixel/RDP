"""
Batch Size Calculator - Calculates actual sizes of all videos via HEAD requests
Run this once to cache sizes, then select_batches.py will show accurate sizes
"""

import os
import re
import json
import requests
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm

def get_file_size(url):
    """Get file size via HEAD request"""
    try:
        response = requests.head(url, timeout=5, allow_redirects=True)
        return int(response.headers.get('content-length', 0))
    except:
        return 0

def parse_batch_file(batch_file):
    """Parse batch file and extract video URLs"""
    batch_id = batch_file.stem.replace('Batch_', '')
    batch_name = None
    video_urls = []
    
    with open(batch_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line.startswith('Course:'):
                course_part = line.replace('Course:', '').strip()
                batch_name = re.sub(r'\s*\(ID:\s*\d+\)\s*$', '', course_part).strip()
            elif ':http' in line:
                # Check if it's a video URL
                if any(ext in line.lower() for ext in ['.mp4', '.webm', '.mkv', 'youtube.com', 'youtu.be', 'm3u8', 'cloudfront.net']):
                    parts = line.split(':http', 1)
                    if len(parts) > 1:
                        url = 'http' + parts[1]
                        video_urls.append(url)
    
    return batch_id, batch_name or f"Batch {batch_id}", video_urls

def main():
    print("=" * 80)
    print("📊 BATCH SIZE CALCULATOR")
    print("=" * 80)
    print()
    
    # Find all batch files
    batch_files = sorted(Path('.').glob('Batch_*.txt'))
    
    if not batch_files:
        print("❌ No Batch_*.txt files found!")
        return
    
    print(f"Found {len(batch_files)} batch files")
    print()
    
    # Load existing cache if available
    cache_file = Path('batch_sizes.json')
    cache = {}
    if cache_file.exists():
        try:
            with open(cache_file, 'r') as f:
                cache = json.load(f)
            print(f"📁 Loaded existing cache ({len(cache)} batches)")
        except:
            cache = {}
    
    # Process each batch
    results = {}
    
    for batch_file in batch_files:
        batch_id, batch_name, video_urls = parse_batch_file(batch_file)
        
        # Skip if already cached
        if batch_id in cache:
            print(f"[✓] {batch_id} - {batch_name} (cached: {cache[batch_id]['size_gb']:.1f} GB)")
            results[batch_id] = cache[batch_id]
            continue
        
        print(f"\n[→] Calculating: {batch_id} - {batch_name}")
        print(f"    {len(video_urls)} videos to check...")
        
        if not video_urls:
            results[batch_id] = {
                'name': batch_name,
                'videos': 0,
                'size_bytes': 0,
                'size_gb': 0.0
            }
            continue
        
        # Calculate sizes in parallel with progress bar
        total_size = 0
        with ThreadPoolExecutor(max_workers=30) as executor:
            futures = {executor.submit(get_file_size, url): url for url in video_urls}
            
            with tqdm(total=len(video_urls), desc=f"    Checking", unit="files") as pbar:
                for future in as_completed(futures):
                    size = future.result()
                    total_size += size
                    pbar.update(1)
        
        size_gb = total_size / (1024 ** 3)
        
        results[batch_id] = {
            'name': batch_name,
            'videos': len(video_urls),
            'size_bytes': total_size,
            'size_gb': round(size_gb, 1)
        }
        
        print(f"    ✅ {len(video_urls)} videos = {size_gb:.1f} GB")
        
        # Save cache after each batch (in case of interruption)
        with open(cache_file, 'w') as f:
            json.dump(results, f, indent=2)
    
    # Final save
    with open(cache_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    # Print summary
    print()
    print("=" * 80)
    print("📊 SUMMARY")
    print("=" * 80)
    
    total_videos = sum(r['videos'] for r in results.values())
    total_gb = sum(r['size_gb'] for r in results.values())
    
    for batch_id, data in sorted(results.items()):
        print(f"  {batch_id}: {data['name'][:50]}")
        print(f"       🎬 {data['videos']} videos | 💾 {data['size_gb']:.1f} GB")
    
    print()
    print(f"📦 TOTAL: {total_videos} videos | {total_gb:.1f} GB")
    print(f"💾 Saved to: {cache_file.absolute()}")
    print()

if __name__ == "__main__":
    main()
