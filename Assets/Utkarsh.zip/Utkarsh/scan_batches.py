"""
Batch Scanner - Creates JSON inventory of all batch files
Scans all Batch_*.txt files and counts videos/PDFs per batch
"""

import os
import re
import json
from pathlib import Path
from datetime import datetime

def parse_batch_file(batch_file):
    """Parse a batch file and extract all sections with video/PDF counts"""
    batch_id = batch_file.stem.replace('Batch_', '')
    sections = []
    current_section = None
    
    with open(batch_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            
            if line.startswith('Course:'):
                # Save previous section
                if current_section:
                    sections.append(current_section)
                
                # Start new section
                course_part = line.replace('Course:', '').strip()
                course_name = re.sub(r'\s*\(ID:\s*\d+\)\s*$', '', course_part).strip()
                
                # Extract ID if present
                id_match = re.search(r'\(ID:\s*(\d+)\)', course_part)
                course_id = id_match.group(1) if id_match else None
                
                current_section = {
                    'course_name': course_name,
                    'course_id': course_id,
                    'info': None,
                    'videos': [],
                    'pdfs': [],
                    'video_count': 0,
                    'pdf_count': 0
                }
            
            elif line.startswith('Info:') and current_section:
                current_section['info'] = line.replace('Info:', '').strip()
            
            elif ':http' in line:
                # Extract title and URL
                parts = line.split(':http', 1)
                if len(parts) == 2:
                    title = parts[0].strip()
                    url = 'http' + parts[1].strip()
                    
                    # Determine if video or PDF
                    if '.pdf' in url.lower():
                        if current_section:
                            current_section['pdfs'].append({'title': title, 'url': url})
                            current_section['pdf_count'] += 1
                    elif any(ext in url.lower() for ext in ['.mp4', '.webm', '.mkv', '.ws', 'youtube.com', 'youtu.be', 'm3u8', 'cloudfront.net']):
                        if current_section:
                            current_section['videos'].append({'title': title, 'url': url})
                            current_section['video_count'] += 1
    
    # Save last section
    if current_section:
        sections.append(current_section)
    
    return batch_id, sections

def main():
    print("=" * 80)
    print("📄 BATCH FILE SCANNER")
    print("=" * 80)
    print()
    
    # Find all batch files
    batch_files = sorted(Path('.').glob('Batch_*.txt'))
    
    if not batch_files:
        print("❌ No Batch_*.txt files found!")
        return
    
    print(f"Found {len(batch_files)} batch files\n")
    
    results = {
        'scan_time': datetime.now().isoformat(),
        'total_batches': len(batch_files),
        'batches': {},
        'summary': {
            'total_videos': 0,
            'total_pdfs': 0,
            'total_sections': 0
        }
    }
    
    for idx, batch_file in enumerate(batch_files, 1):
        print(f"[{idx}/{len(batch_files)}] Scanning {batch_file.name}...", end='\r')
        
        batch_id, sections = parse_batch_file(batch_file)
        
        # Calculate totals for this batch
        total_videos = sum(s['video_count'] for s in sections)
        total_pdfs = sum(s['pdf_count'] for s in sections)
        
        # Get main batch name (first section)
        batch_name = sections[0]['course_name'] if sections else f"Batch {batch_id}"
        
        # Create sections summary (without full URL lists for smaller JSON)
        sections_summary = []
        for s in sections:
            sections_summary.append({
                'course_name': s['course_name'],
                'course_id': s['course_id'],
                'info': s['info'],
                'video_count': s['video_count'],
                'pdf_count': s['pdf_count']
            })
        
        results['batches'][batch_id] = {
            'batch_name': batch_name,
            'file': str(batch_file),
            'total_videos': total_videos,
            'total_pdfs': total_pdfs,
            'section_count': len(sections),
            'sections': sections_summary
        }
        
        results['summary']['total_videos'] += total_videos
        results['summary']['total_pdfs'] += total_pdfs
        results['summary']['total_sections'] += len(sections)
    
    # Save to JSON
    output_file = Path('batch_inventory.json')
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    
    print("\n" + "=" * 80)
    print("📊 SUMMARY")
    print("=" * 80)
    print(f"  📦 Total Batches: {len(batch_files)}")
    print(f"  📂 Total Sections: {results['summary']['total_sections']}")
    print(f"  🎬 Total Videos: {results['summary']['total_videos']}")
    print(f"  📄 Total PDFs: {results['summary']['total_pdfs']}")
    print()
    print(f"💾 Saved to: {output_file.absolute()}")
    print()
    
    # Print top 10 batches by video count
    print("=" * 80)
    print("📈 TOP 10 BATCHES BY VIDEO COUNT")
    print("=" * 80)
    sorted_batches = sorted(
        results['batches'].items(), 
        key=lambda x: x[1]['total_videos'], 
        reverse=True
    )[:10]
    
    for batch_id, data in sorted_batches:
        print(f"  🎬 {data['total_videos']:5} | 📄 {data['total_pdfs']:4} | {batch_id} {data['batch_name'][:45]}")
    
    print()

if __name__ == "__main__":
    main()
