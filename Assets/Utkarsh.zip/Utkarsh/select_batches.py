"""
Interactive Batch Selector - Choose which batches to download
Uses batch_inventory.json and folder_inventory.json for accurate status
"""

import os
import json
from pathlib import Path

def main():
    print("=" * 80)
    print("🎓 UTKARSH BATCH SELECTOR")
    print("=" * 80)
    print()
    
    # Load batch inventory
    batch_inv_file = Path('batch_inventory.json')
    if not batch_inv_file.exists():
        print("❌ batch_inventory.json not found!")
        print("💡 Run 'python scan_batches.py' first")
        return
    
    with open(batch_inv_file, 'r', encoding='utf-8') as f:
        batch_inventory = json.load(f)
    
    # Load folder inventory
    folder_inv_file = Path('folder_inventory.json')
    folder_inventory = {}
    if folder_inv_file.exists():
        with open(folder_inv_file, 'r', encoding='utf-8') as f:
            folder_inventory = json.load(f)
        print(f"📂 Loaded folder inventory ({len(folder_inventory.get('folders', {}))} folders)")
    else:
        print("⚠️ folder_inventory.json not found - run 'python scan_directory.py'")
    
    # Load size cache if available
    size_cache = {}
    if Path('batch_sizes.json').exists():
        try:
            with open('batch_sizes.json', 'r') as f:
                size_cache = json.load(f)
            print(f"📊 Loaded size cache ({len(size_cache)} batches)")
        except:
            pass
    print()
    
    # Display available batches
    print("📚 Available Batches:")
    print()
    
    batch_info = []
    folder_data = folder_inventory.get('folders', {})
    
    # Sort batches by ID
    sorted_batches = sorted(batch_inventory['batches'].items(), key=lambda x: x[0])
    
    for idx, (batch_id, data) in enumerate(sorted_batches, 1):
        batch_name = data['batch_name']
        total_videos = data['total_videos']
        total_pdfs = data['total_pdfs']
        sections = data['sections']
        
        # Calculate downloaded files from folder inventory
        downloaded_mp4 = 0
        downloaded_pdf = 0
        
        for section in sections:
            course_name = section['course_name']
            # Find matching folder in inventory
            if course_name in folder_data:
                downloaded_mp4 += folder_data[course_name]['mp4_count']
                downloaded_pdf += folder_data[course_name]['pdf_count']
        
        # Get size from cache or estimate
        if batch_id in size_cache:
            size_gb = size_cache[batch_id]['size_gb']
            size_indicator = "💾"
        else:
            size_gb = (total_videos * 700) / 1024
            size_indicator = "📏"
        
        # Determine status
        if downloaded_mp4 == 0:
            status = "📥 NEW"
        elif downloaded_mp4 >= total_videos:
            status = f"✅ DONE ({downloaded_mp4}/{total_videos})"
        else:
            remaining = total_videos - downloaded_mp4
            status = f"⏳ {downloaded_mp4}/{total_videos} ({remaining} left)"
        
        batch_info.append({
            'idx': idx,
            'file': data['file'],
            'id': batch_id,
            'name': batch_name,
            'videos': total_videos,
            'pdfs': total_pdfs,
            'downloaded_mp4': downloaded_mp4,
            'downloaded_pdf': downloaded_pdf,
            'size_gb': size_gb,
            'status': status
        })
        
        print(f"[{idx}] {batch_id} {batch_name}")
        print(f"    🎬 {total_videos} videos | 📄 {total_pdfs} PDFs | {size_indicator} {size_gb:.0f} GB | {status}")
        print()
    
    print("=" * 80)
    print()
    
    # Get user selection
    print("Select batches to download:")
    print("  • Enter batch number (e.g., 1)")
    print("  • Enter multiple numbers separated by comma (e.g., 1,3,4)")
    print("  • Enter 'all' to download all batches")
    print("  • Enter 'q' to quit")
    print()
    
    selection = input("Your choice: ").strip().lower()
    
    if selection == 'q':
        print("Cancelled.")
        return
    
    # Parse selection
    selected_batches = []
    
    if selection == 'all':
        selected_batches = [b['file'] for b in batch_info]
    else:
        try:
            indices = [int(x.strip()) for x in selection.split(',')]
            for idx in indices:
                if 1 <= idx <= len(batch_info):
                    selected_batches.append(batch_info[idx-1]['file'])
                else:
                    print(f"⚠️  Invalid batch number: {idx}")
        except ValueError:
            print("❌ Invalid input format")
            return
    
    if not selected_batches:
        print("❌ No batches selected")
        return
    
    # Confirm selection
    print()
    print("=" * 80)
    print("📦 Selected Batches:")
    print("=" * 80)
    total_videos = 0
    for batch_file in selected_batches:
        info = next(b for b in batch_info if b['file'] == batch_file)
        print(f"  • {info['name']} ({info['videos']} videos)")
        total_videos += info['videos']
    
    print()
    print(f"📊 Total: {total_videos} videos from {len(selected_batches)} batch(es)")
    print("=" * 80)
    print()
    
    confirm = input("Start download? (y/n): ").strip().lower()
    
    if confirm != 'y':
        print("Cancelled.")
        return
    
    # Build and execute command
    print()
    print("🚀 Starting downloader...")
    print()
    
    import subprocess
    import sys
    
    # Check for flags
    no_upload = '--no-upload' in sys.argv
    parallel = 4  # Default: 4 parallel downloads
    for i, arg in enumerate(sys.argv):
        if arg == '--parallel' and i + 1 < len(sys.argv):
            try:
                parallel = int(sys.argv[i + 1])
            except:
                parallel = 4
        elif arg.startswith('--parallel='):
            try:
                parallel = int(arg.split('=')[1])
            except:
                parallel = 4
    
    if no_upload:
        print(f"💾 LOCAL-ONLY MODE - No Google Drive upload")
        print(f"⚡ Using {parallel} parallel connections\n")
        folder_id = None
    else:
        folder_id = "1IWVaNtjMx5_lLWaCENmMwj1Bk7C21vZo"
    
    for batch_file in selected_batches:
        info = next(b for b in batch_info if b['file'] == batch_file)
        
        print(f"\n{'='*80}")
        print(f"📦 Processing: {info['name']}")
        print(f"{'='*80}\n")
        
        # Run downloader for this specific batch
        if no_upload:
            cmd = f'python batch_video_downloader_v2.py --batch {info["id"]} --no-upload --parallel {parallel}'
        else:
            cmd = f'python batch_video_downloader_v2.py --batch {info["id"]} --folder {folder_id} --parallel {parallel}'
        
        result = subprocess.run(cmd, shell=True)
        
        if result.returncode != 0:
            print(f"\n⚠️  Batch {info['id']} encountered errors")
            cont = input("Continue with next batch? (y/n): ").strip().lower()
            if cont != 'y':
                break
    
    print()
    print("=" * 80)
    print("✅ Download process complete!")
    print("=" * 80)
    print()
    if no_upload:
        print(f"📁 Check your Downloads folder:")
        print(f"   Downloads/Batch_<ID>/")
    else:
        print(f"📁 Check your Google Drive folder:")
        print(f"   https://drive.google.com/drive/folders/1IWVaNtjMx5_lLWaCENmMwj1Bk7C21vZo")
    print()

if __name__ == "__main__":
    main()
