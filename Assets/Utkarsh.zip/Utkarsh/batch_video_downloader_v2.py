"""
Batch Video Downloader V2 - Multi-Section Support
Downloads videos from Utkarsh batch files and uploads to Google Drive
Supports multiple courses within a single batch file
"""

import os
import re
import sys
import signal
import requests
import time
import logging
from pathlib import Path
from tqdm import tqdm
import argparse

# Fix Windows console encoding for Hindi characters
if sys.platform == 'win32':
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')
    sys.stderr.reconfigure(encoding='utf-8', errors='replace')

# Handle Ctrl+C gracefully
def signal_handler(sig, frame):
    print("\n\n⚠️  Ctrl+C detected! Stopping downloads...")
    os._exit(0)

signal.signal(signal.SIGINT, signal_handler)

# Import yt-dlp
try:
    import yt_dlp as youtube_dl
except ImportError:
    import youtube_dl

# Import Google Drive functions
from gdrive import get_drive_service, create_folder, upload_file, check_file_exists

# Setup logging - file only to avoid Unicode issues
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('downloader.log', encoding='utf-8')
    ]
)

class BatchVideoDownloader:
    def __init__(self, parent_folder_id=None, keep_local=False, no_upload=False, parallel_downloads=1):
        self.drive_service = None
        self.parent_folder_id = parent_folder_id
        self.keep_local = keep_local
        self.no_upload = no_upload
        self.parallel_downloads = parallel_downloads
        self.stats = {
            'downloaded': 0,
            'uploaded': 0,
            'skipped': 0,
            'failed': 0,
            'moved': 0
        }
        
        # Add thread lock for stats
        from threading import Lock, Thread
        from queue import Queue
        self.stats_lock = Lock()
        
        # Transfer queue for background file moving
        self.transfer_queue = Queue()
        self.transfer_worker_running = False
        self.transfer_threads = []
        self.num_transfer_workers = 1
        
        # Progress bar manager for multi-progress display
        self.progress_lock = Lock()
        self.active_progress_bars = {}
        self.progress_position_counter = 0
        
        # Overall progress counter
        self.videos_processed = 0
        self.videos_total = 0
    
    def start_transfer_worker(self):
        """Start background transfer worker threads"""
        from threading import Thread
        if not self.transfer_worker_running:
            self.transfer_worker_running = True
            for i in range(self.num_transfer_workers):
                t = Thread(target=self._transfer_worker, daemon=True, name=f"TransferWorker-{i+1}")
                t.start()
                self.transfer_threads.append(t)
            print(f"   🔄 {self.num_transfer_workers} background transfer workers started")
    
    def stop_transfer_worker(self):
        """Stop transfer workers and wait for queue to empty"""
        if self.transfer_worker_running:
            # Wait for queue to empty
            self.transfer_queue.join()
            self.transfer_worker_running = False
            print(f"   ✅ All transfers complete ({self.stats.get('moved', 0)} files moved)")
    
    def _transfer_worker(self):
        """Background worker that moves files from temp to destination"""
        import shutil
        import time
        while self.transfer_worker_running or not self.transfer_queue.empty():
            try:
                # Get item with timeout to allow checking running flag
                item = self.transfer_queue.get(timeout=1)
                source_path, dest_path, title = item
                
                # Wait briefly for aria2c to release file handle
                time.sleep(0.5)
                
                # Retry move with delays
                for attempt in range(5):
                    try:
                        if attempt > 0:
                            time.sleep(1)
                        shutil.move(str(source_path), str(dest_path))
                        with self.stats_lock:
                            self.stats['moved'] += 1
                        break
                    except PermissionError:
                        if attempt == 4:
                            if dest_path.exists():
                                pass  # Already moved
                    except Exception:
                        break
                
                self.transfer_queue.task_done()
            except:
                pass  # Queue timeout, continue loop

    
    def clean_url(self, url):
        """Clean and validate URL, fix malformed YouTube embeds and other issues"""
        # Fix YouTube embed with nested YouTube URL
        if 'youtube.com/embed/http' in url or 'youtube.com/embed/https' in url:
            # Extract the nested URL
            match = re.search(r'youtube\.com/embed/(https?://[^\s]+)', url)
            if match:
                url = match.group(1)
        
        # Fix triple slashes (https:///)
        url = re.sub(r'(https?:)/{3,}', r'\1//', url)
        
        # Fix missing http/https
        if url.startswith('//'):
            url = 'https:' + url
        
        return url
    
    def estimate_batch_size(self, sections):
        """Estimate total size of all videos in batch using HEAD requests"""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        
        print("\n📊 Estimating batch size...")
        
        # Collect all video URLs
        all_videos = []
        for section in sections:
            all_videos.extend(section.get('videos', []))
        
        total_size = 0
        checked = 0
        
        def get_file_size(url):
            try:
                response = requests.head(url, timeout=5)
                return int(response.headers.get('content-length', 0))
            except:
                return 0
        
        # Check sizes in parallel (fast)
        with ThreadPoolExecutor(max_workers=20) as executor:
            futures = {executor.submit(get_file_size, url): url for (title, url) in all_videos}
            
            for future in as_completed(futures):
                size = future.result()
                total_size += size
                checked += 1
                
                # Show progress every 50 files
                if checked % 50 == 0:
                    print(f"   Checked {checked}/{len(all_videos)} files...", end="\r")
        
        # Calculate stats
        total_gb = total_size / (1024 ** 3)
        avg_size_mb = (total_size / len(all_videos)) / (1024 ** 2) if all_videos else 0
        
        # Estimate time at 5 MiB/s average speed
        est_hours = total_size / (5 * 1024 * 1024) / 3600
        
        print(f"\n   📁 Total Videos: {len(all_videos)}")
        print(f"   💾 Total Size: {total_gb:.1f} GB")
        print(f"   📄 Avg Size: {avg_size_mb:.0f} MB per video")
        print(f"   ⏱️  Est. Time: {est_hours:.1f} hours @ 5 MiB/s")
        print()
        
        return total_size
    
    def init_drive(self):
        """Initialize Google Drive service"""
        if not self.drive_service:
            print("\n🔐 Initializing Google Drive...")
            self.drive_service = get_drive_service()
            print("   ✅ Google Drive connected")
    
    def parse_batch_file_multisection(self, txt_file):
        """
        Parse a batch .txt file that may contain multiple courses/sections
        
        Returns:
            tuple: (batch_id, list of sections)
            Each section is a dict: {
                'course_name': str,
                'info': str,
                'videos': [(title, url), ...]
            }
        """
        print(f"\n📄 Parsing: {txt_file}")
        
        # Extract batch ID from filename
        batch_id = re.search(r'Batch_(\d+)', txt_file).group(1)
        
        sections = []
        current_section = None
        
        with open(txt_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                
                # Check for Course: line (starts a new section)
                if line.startswith('Course:'):
                    # Save previous section if exists
                    if current_section and current_section['videos']:
                        sections.append(current_section)
                    
                    # Start new section
                    course_part = line.replace('Course:', '').strip()
                    course_name = re.sub(r'\s*\(ID:\s*\d+\)\s*$', '', course_part).strip()
                    
                    current_section = {
                        'course_name': course_name,
                        'info': None,
                        'videos': []
                    }
                
                # Check for Info: line
                elif line.startswith('Info:') and current_section:
                    current_section['info'] = line.replace('Info:', '').strip()
                
                # Check for video URLs
                elif ':http' in line and current_section:
                    parts = line.split(':http', 1)
                    title = parts[0].strip()
                    url = 'http' + parts[1].strip()
                    
                    # Clean URL
                    url = self.clean_url(url)
                    
                    # Check if it's a video
                    is_video = any(ext in url.lower() for ext in [
                        '.mp4', '.webm', '.mkv', '.avi', '.mov', '.flv',
                        '.wmv', '.m4v', '.ws',
                        'youtube.com', 'youtu.be',
                        'cloudfront.net',
                        '/videos/',
                    ])
                    
                    is_pdf = '.pdf' in url.lower()
                    
                    if is_video and not is_pdf:
                        current_section['videos'].append((title, url))
                    elif is_pdf:
                        # Add PDFs to a separate list
                        if 'pdfs' not in current_section:
                            current_section['pdfs'] = []
                        current_section['pdfs'].append((title, url))
        
        # Save last section
        if current_section and (current_section['videos'] or current_section.get('pdfs', [])):
            sections.append(current_section)
        
        # Print summary
        print(f"   Batch ID: {batch_id}")
        print(f"   Found {len(sections)} course sections:")
        for i, section in enumerate(sections, 1):
            video_count = len(section['videos'])
            pdf_count = len(section.get('pdfs', []))
            print(f"      [{i}] {section['course_name']}: {video_count} videos, {pdf_count} PDFs")
        
        return batch_id, sections
    
    def sanitize_filename(self, filename):
        """Sanitize filename for Windows/Drive"""
        # Remove control characters (tabs, newlines, etc.)
        filename = re.sub(r'[\t\n\r\f\v]', ' ', filename)
        
        # Remove invalid Windows characters
        filename = re.sub(r'[<>:"/\\|?*]', '_', filename)
        
        # Replace multiple spaces with single space
        filename = re.sub(r'\s+', ' ', filename)
        
        # Strip leading/trailing spaces and dots
        filename = filename.strip(' .')
        
        # Limit length
        if len(filename) > 200:
            filename = filename[:200]
        
        return filename
    
    def download_youtube(self, url, output_path, title):
        """Download YouTube video using yt-dlp with aria2c downloader"""
        try:
            ydl_opts = {
                'outtmpl': str(output_path),
                'format': 'bv*+ba/best[ext=mp4]/best',  # Better format selection
                'quiet': True,
                'no_warnings': True,
                'ignoreerrors': False,
                'nocheckcertificate': True,
                'geo_bypass': True,
                'nopart': False,
                'overwrites': False,
                # Use aria2c as external downloader for speed (quiet mode)
                'external_downloader': 'aria2c',
                'external_downloader_args': {
                    'aria2c': ['-x8', '-s8', '-k5M', '--file-allocation=trunc', '--disable-ipv6=true', '--retry-wait=3', '--max-tries=10', '--quiet=true', '--console-log-level=error']
                },
                'merge_output_format': 'mp4',
                'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'extractor_args': {'youtube': {'player_client': ['android', 'web']}},
                'http_headers': {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
                    'Accept-Language': 'en-us,en;q=0.5',
                    'Sec-Fetch-Mode': 'navigate',
                }
            }
            
            with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                try:
                    ydl.download([url])
                except Exception as download_error:
                    # Check if error is just rename failure but file exists
                    error_msg = str(download_error)
                    if 'Unable to rename file' in error_msg or 'WinError 32' in error_msg:
                        print(f"      ⚠️  Rename failed, but download may be complete")
                        # Continue to rename logic below
                    else:
                        raise  # Re-raise if it's a real download error
            
            # Check if .part file exists and rename it
            part_path = Path(str(output_path) + '.part')
            if part_path.exists():
                import time
                print(f"      🔄 Renaming .part file...")
                # Retry a few times in case file is locked
                for i in range(5):
                    try:
                        time.sleep(1)  # Wait for any file locks to release
                        part_path.rename(output_path)
                        print(f"      ✅ Rename successful!")
                        break
                    except Exception as e:
                        if i < 4:
                            print(f"      ⏳ Waiting for file lock... (attempt {i+1}/5)")
                        else:
                            print(f"      ⚠️  Could not rename, but file downloaded: {part_path}")
            
            # Check if final file exists (either renamed successfully or already there)
            if output_path.exists() or part_path.exists():
                return True
            
            return True
        except Exception as e:
            # Check if file was downloaded despite error
            if output_path.exists() or Path(str(output_path) + '.part').exists():
                print(f"      ✅ File downloaded despite error")
                return True
            
            # Try with simpler format
            try:
                print(f"      ⚠️  Retrying with alternative format...")
                ydl_opts['format'] = 'best/worst'
                ydl_opts['extractor_args'] = {'youtube': {'player_client': ['android']}}
                with youtube_dl.YoutubeDL(ydl_opts) as ydl:
                    try:
                        ydl.download([url])
                    except Exception as download_error:
                        if 'Unable to rename file' in str(download_error):
                            pass  # Ignore rename errors
                        else:
                            raise
                
                # Check and rename .part file
                part_path = Path(str(output_path) + '.part')
                if part_path.exists():
                    import time
                    for i in range(5):
                        try:
                            time.sleep(1)
                            part_path.rename(output_path)
                            break
                        except:
                            pass
                
                if output_path.exists() or part_path.exists():
                    return True
                return True
            except:
                # Last resort: try with built-in downloader (no aria2c, better for HLS)
                try:
                    ydl_opts_builtin = {
                        'outtmpl': str(output_path),
                        'format': 'bv*+ba/best[ext=mp4]/best',
                        'quiet': True,
                        'no_warnings': True,
                        'ignoreerrors': False,
                        'nocheckcertificate': True,
                        'geo_bypass': True,
                        'nopart': False,
                        'overwrites': False,
                        # No external_downloader - use built-in (more reliable for HLS)
                        'merge_output_format': 'mp4',
                        'retries': 10,
                        'fragment_retries': 10,
                        'user_agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                    }
                    
                    with youtube_dl.YoutubeDL(ydl_opts_builtin) as ydl:
                        ydl.download([url])
                    
                    if output_path.exists() or Path(str(output_path) + '.part').exists():
                        return True
                    return True
                except Exception as e2:
                    logging.error(f"All download attempts failed for {title}: {str(e2)}")
                    return False
    
    def download_aria2c(self, url, output_path, title, file_size=0):
        """Download using aria2c with optimized settings"""
        try:
            import subprocess
            import threading
            
            # Adaptive splits based on file size
            if file_size > 500 * 1024 * 1024:  # > 500MB
                splits = 12
            elif file_size > 50 * 1024 * 1024:  # > 50MB
                splits = 8
            else:
                splits = 4
            
            # Progress bar will show the title instead of printing
            
            # Optimized aria2c command
            cmd = [
                'aria2c',
                f'--max-connection-per-server={splits}',
                f'--split={splits}',
                '--min-split-size=5M',
                '--file-allocation=trunc',           # Faster disk writes
                '--enable-http-pipelining=true',     # Less overhead
                '--http-accept-gzip=true',
                '--auto-file-renaming=false',
                '--console-log-level=error',
                '--summary-interval=0',
                '--download-result=hide',
                '--continue=true',
                '--max-tries=10',                    # More retries
                '--retry-wait=3',
                '--quiet=true',
                '--timeout=60',                      # Longer timeout
                '--connect-timeout=30',
                '--disable-ipv6=true',               # Force IPv4 to fix network errors
                '--dir', str(output_path.parent),
                '--out', output_path.name,
                url
            ]
            
            # Start download process
            process = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # Monitor file size and show progress bar
            from tqdm import tqdm
            import time
            
            # Wait a moment for file to be created
            time.sleep(0.5)
            
            # Try to get file size from headers (use passed file_size if available)
            total_size = file_size
            if total_size == 0:
                try:
                    response = requests.head(url, timeout=5)
                    total_size = int(response.headers.get('content-length', 0))
                except:
                    total_size = 0
            
            # Get a unique position for this progress bar
            with self.progress_lock:
                position = self.progress_position_counter % self.parallel_downloads
                self.progress_position_counter += 1
            
            # Short title for progress bar (max 30 chars)
            short_title = title[:30] + "..." if len(title) > 30 else title
            
            # Show progress bar with fixed position (1+ to leave room for main counter)
            if total_size > 0:
                with tqdm(
                    total=total_size, 
                    unit='iB', 
                    unit_scale=True, 
                    unit_divisor=1024, 
                    desc=f"[{short_title}]",
                    position=position + 1,  # +1 to leave room for main counter
                    leave=False,
                    ncols=100
                ) as pbar:
                    last_size = 0
                    while process.poll() is None:
                        try:
                            if output_path.exists():
                                current_size = output_path.stat().st_size
                                pbar.update(current_size - last_size)
                                last_size = current_size
                        except:
                            pass
                        time.sleep(0.3)
                    
                    # Final update
                    if output_path.exists():
                        final_size = output_path.stat().st_size
                        pbar.update(final_size - last_size)
            else:
                # No size info, just wait for completion
                process.wait()
            
            if process.returncode == 0:
                return True
            else:
                # Silent fallback - progress bar will show
                return False
                
        except FileNotFoundError:
            return False
        except Exception as e:
            return False  # Silent fallback
    
    def download_direct(self, url, output_path, title):
        """Download direct video link with retry and resume support"""
        max_retries = 3
        
        for attempt in range(max_retries):
            try:
                # Progress bar will show title, no need to print here
                
                # Check for existing partial file
                headers = {}
                existing_size = 0
                if output_path.exists():
                    existing_size = output_path.stat().st_size
                    headers['Range'] = f'bytes={existing_size}-'
                
                response = requests.get(url, stream=True, timeout=60, headers=headers)
                
                # Handle resume response
                if response.status_code == 206:  # Partial content
                    total_size = existing_size + int(response.headers.get('content-length', 0))
                    mode = 'ab'  # Append mode
                else:
                    response.raise_for_status()
                    total_size = int(response.headers.get('content-length', 0))
                    mode = 'wb'
                    existing_size = 0
                
                # Get a unique position for this progress bar
                with self.progress_lock:
                    position = self.progress_position_counter % self.parallel_downloads
                
                # Short title for progress bar
                short_title = title[:30] + "..." if len(title) > 30 else title
                
                with open(output_path, mode) as f, tqdm(
                    desc=f"[{short_title}]",
                    total=total_size,
                    initial=existing_size,
                    unit='iB',
                    unit_scale=True,
                    unit_divisor=1024,
                    position=position,
                    leave=False,
                    ncols=100
                ) as pbar:
                    for chunk in response.iter_content(chunk_size=65536):
                        if chunk:
                            f.write(chunk)
                            pbar.update(len(chunk))
                
                return True
                
            except Exception as e:
                logging.error(f"Direct download attempt {attempt+1} failed for {title}: {str(e)}")
                if attempt < max_retries - 1:
                    import time
                    time.sleep(5)  # Silent retry
                else:
                    return False
        return False
    
    def download_video(self, title, url, output_dir):
        """Download a video from URL"""
        # Validate URL first
        if not url or url.strip() == '' or url == 'http' or url == 'https':
            print(f"   ⚠️  Invalid/empty URL, skipping...")
            with self.stats_lock:
                self.stats['failed'] += 1
            return None
        
        safe_name = self.sanitize_filename(title)
        output_path = output_dir / f"{safe_name}.mp4"
        
        # Check if already downloaded (complete or partial)
        if output_path.exists():
            with self.stats_lock:
                self.stats['skipped'] += 1
            return output_path
        
        # Also check for .part file (partial download from previous run)
        part_path = Path(str(output_path) + '.part')
        if part_path.exists():
            pass  # Will resume
        
        # Determine download method
        if 'youtube.com' in url or 'youtu.be' in url:
            print(f"   🎬 Downloading from YouTube (with aria2c)...")
            if self.download_youtube(url, output_path, title):
                with self.stats_lock:
                    self.stats['downloaded'] += 1
                return output_path
        else:
            # Check if it's an HLS stream (.m3u8) - use yt-dlp for these
            if '.m3u8' in url or 'video.m3u8' in url:
                print(f"   🎬 HLS stream detected, using yt-dlp...")
                if self.download_youtube(url, output_path, title):
                    with self.stats_lock:
                        self.stats['downloaded'] += 1
                    return output_path
            
            # Get file size for adaptive strategy
            file_size = 0
            try:
                response = requests.head(url, timeout=5)
                file_size = int(response.headers.get('content-length', 0))
            except:
                pass
            
            # Small files (<50MB): use direct download (less overhead)
            if file_size > 0 and file_size < 50 * 1024 * 1024:
                if self.download_direct(url, output_path, title):
                    with self.stats_lock:
                        self.stats['downloaded'] += 1
                    return output_path
            
            # Large files: use aria2c with adaptive splits
            if self.download_aria2c(url, output_path, title, file_size):
                with self.stats_lock:
                    self.stats['downloaded'] += 1
                return output_path
            # Fallback to direct download
            elif self.download_direct(url, output_path, title):
                with self.stats_lock:
                    self.stats['downloaded'] += 1
                return output_path
        
        with self.stats_lock:
            self.stats['failed'] += 1
        return None
    
    def download_pdf(self, title, url, output_dir):
        """Download a PDF file"""
        safe_name = self.sanitize_filename(title)
        output_path = output_dir / f"{safe_name}.pdf"
        
        # Check if already downloaded
        if output_path.exists():
            print(f"   ⏭️  Already exists, skipping")
            with self.stats_lock:
                self.stats['skipped'] += 1
            return output_path
        
        # Try aria2c first
        print(f"   📥 Downloading PDF with aria2c...")
        if self.download_aria2c(url, output_path, title):
            with self.stats_lock:
                self.stats['downloaded'] += 1
            return output_path
        # Fallback to direct download
        elif self.download_direct(url, output_path, title):
            with self.stats_lock:
                self.stats['downloaded'] += 1
            return output_path
        
        with self.stats_lock:
            self.stats['failed'] += 1
        return None
    
    def progress_hook(self, d, phase):
        """Progress hook for yt-dlp"""
        if d['status'] == 'downloading':
            if 'total_bytes' in d:
                percent = (d['downloaded_bytes'] / d['total_bytes']) * 100
                print(f"\r   Progress: {percent:.1f}%", end='', flush=True)
        elif d['status'] == 'finished':
            print(f"\r   ✅ Download complete!          ")
    
    def process_batch(self, txt_file):
        """Process a single batch file with multiple sections"""
        print(f"\n{'='*80}")
        print(f"📦 Processing: {txt_file}")
        print(f"{'='*80}")
        
        # Parse file
        batch_id, sections = self.parse_batch_file_multisection(txt_file)
        
        if not sections:
            print("⚠️  No videos found in this batch")
            return
        
        # Initialize Drive only if uploading
        if not self.no_upload:
            self.init_drive()
            
            # Create main batch folder
            batch_folder_name = f"Batch_{batch_id}"
            print(f"\n📁 Creating main Drive folder: {batch_folder_name}")
            
            batch_folder_id = create_folder(
                self.drive_service,
                batch_folder_name,
                self.parent_folder_id
            )
            
            if not batch_folder_id:
                print("❌ Failed to create main batch folder!")
                return
            
            print(f"   ✅ Main folder created (ID: {batch_folder_id})")
        else:
            print(f"\n💾 Local-only mode - skipping Google Drive upload")
            batch_folder_id = None
        
        # Start downloading immediately (size already shown in batch selection)
        
        # Process each section
        for section_idx, section in enumerate(sections, 1):
            print(f"\n{'─'*80}")
            print(f"📂 Section {section_idx}/{len(sections)}: {section['course_name']}")
            print(f"{'─'*80}")
            
            # Create folder structure (Drive or local)
            if not self.no_upload:
                # Create course subfolder on Drive
                course_folder_name = self.sanitize_filename(section['course_name'])
                print(f"   Creating Drive subfolder: {course_folder_name}")
                
                course_folder_id = create_folder(
                    self.drive_service,
                    course_folder_name,
                    batch_folder_id
                )
                
                if not course_folder_id:
                    print(f"   ❌ Failed to create course folder, skipping section")
                    continue
                
                # Create subfolder for Info if exists
                final_folder_id = course_folder_id
                if section['info']:
                    info_folder_name = section['info'].replace(':', '').replace(',', '').strip()
                    print(f"   Creating info subfolder: {info_folder_name}")
                    
                    info_folder_id = create_folder(
                        self.drive_service,
                        info_folder_name,
                        course_folder_id
                    )
                    
                    if info_folder_id:
                        final_folder_id = info_folder_id
                
                # Create local temp directory
                local_dir = Path(f"temp_{batch_id}_{section_idx}")
                final_dest_dir = None  # Not used in upload mode
            else:
                # Local-only mode:
                # 1. Download to temp folder (fast local processing)
                # 2. Move completed files to E: drive (final destination)
                
                # Temp folder for downloading (current directory)
                local_dir = Path(f"temp_{batch_id}_{section_idx}")
                
                # Final destination on E: drive (no Batch_id, just folder name)
                final_output_base = Path(r"E:\My Drive\Classplus (~1.2Tb)")
                final_dest_dir = final_output_base / self.sanitize_filename(section['course_name'])
                if section['info']:
                    info_folder_name = section['info'].replace(':', '').replace(',', '').strip()
                    final_dest_dir = final_dest_dir / self.sanitize_filename(info_folder_name)
                
                # Create both directories
                final_dest_dir.mkdir(parents=True, exist_ok=True)
                final_folder_id = None
            
            local_dir.mkdir(parents=True, exist_ok=True)
            print(f"   📁 Temp folder: {local_dir}")
            if final_dest_dir:
                print(f"   📁 Final destination: {final_dest_dir}")
            # Start background transfer worker for local-only mode
            if self.no_upload and final_dest_dir:
                self.start_transfer_worker()
            
            # Process videos
            videos = section['videos']
            print(f"\n   🎬 Processing {len(videos)} videos...")
            
            if self.parallel_downloads > 1:
                print(f"   ⚡ Using {self.parallel_downloads} parallel connections")
                self._process_videos_parallel(videos, local_dir, final_folder_id, final_dest_dir)
            else:
                self._process_videos_sequential(videos, local_dir, final_folder_id, final_dest_dir)
            
            # Process PDFs if any
            pdfs = section.get('pdfs', [])
            if pdfs:
                print(f"\n   📄 Processing {len(pdfs)} PDFs...")
                
                if self.parallel_downloads > 1:
                    print(f"   ⚡ Using {self.parallel_downloads} parallel connections")
                    self._process_pdfs_parallel(pdfs, local_dir, final_folder_id, final_dest_dir)
                else:
                    self._process_pdfs_sequential(pdfs, local_dir, final_folder_id, final_dest_dir)
            
            # Cleanup temp directory only if uploading and not keeping local
            if not self.no_upload and not self.keep_local:
                try:
                    local_dir.rmdir()
                except:
                    pass
            
            print(f"\n   ✅ Section {section_idx} complete!")
        
        # Wait for all background transfers to complete
        if self.no_upload:
            self.stop_transfer_worker()
            
            # Cleanup all temp folders after transfers complete
            import shutil
            for section_idx in range(1, len(sections) + 1):
                temp_dir = Path(f"temp_{batch_id}_{section_idx}")
                if temp_dir.exists():
                    try:
                        shutil.rmtree(temp_dir)
                        print(f"   🗑️  Cleaned up: {temp_dir}")
                    except:
                        pass
        
        print(f"\n✅ Batch {batch_id} complete!")
    
    def _process_single_video(self, idx, total, title, url, local_dir, final_folder_id, final_dest_dir=None):
        """Process a single video download and optional upload/move"""
        safe_filename = self.sanitize_filename(title)
        
        # Check if already exists on Drive (for upload mode)
        if not self.no_upload and final_folder_id and check_file_exists(self.drive_service, safe_filename, final_folder_id):
            with self.stats_lock:
                self.stats['skipped'] += 1
            return
        
        # Check if already exists in final destination (for local-only mode)
        if self.no_upload and final_dest_dir:
            final_path = final_dest_dir / f"{safe_filename}.mp4"
            if final_path.exists():
                with self.stats_lock:
                    self.stats['skipped'] += 1
                return
        
        # Download video to temp folder
        local_path = self.download_video(title, url, local_dir)
        
        if not local_path or not os.path.exists(local_path):
            return
        
        # Upload to Drive if not in local-only mode
        if not self.no_upload and final_folder_id:
            upload_id = upload_file(
                self.drive_service,
                local_path,
                final_folder_id,
                os.path.basename(local_path)
            )
            
            if upload_id:
                with self.stats_lock:
                    self.stats['uploaded'] += 1
                
                # Delete local file
                if not self.keep_local:
                    try:
                        os.remove(local_path)
                    except:
                        pass
            else:
                with self.stats_lock:
                    self.stats['failed'] += 1
        else:
            # Local-only mode - queue file for background transfer
            if final_dest_dir:
                final_path = final_dest_dir / os.path.basename(local_path)
                
                # Check if already exists in destination
                if final_path.exists():
                    try:
                        os.remove(local_path)
                    except:
                        pass
                else:
                    # Queue for background transfer
                    self.transfer_queue.put((Path(local_path), final_path, title))
        
        time.sleep(0.1)
    
    def _process_videos_sequential(self, videos, local_dir, final_folder_id, final_dest_dir=None):
        """Process videos one at a time"""
        for idx, (title, url) in enumerate(videos, 1):
            self._process_single_video(idx, len(videos), title, url, local_dir, final_folder_id, final_dest_dir)
    
    def _process_videos_parallel(self, videos, local_dir, final_folder_id, final_dest_dir=None):
        """Process multiple videos in parallel"""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        
        # Set total for this section
        self.videos_total = len(videos)
        self.videos_processed = 0
        
        # Print initial counter (will be updated in-place)
        print(f"[0/{len(videos)}]")
        
        with ThreadPoolExecutor(max_workers=self.parallel_downloads) as executor:
            futures = []
            for idx, (title, url) in enumerate(videos, 1):
                future = executor.submit(
                    self._process_single_video,
                    idx, len(videos), title, url, local_dir, final_folder_id, final_dest_dir
                )
                futures.append(future)
            
            # Wait for all to complete and update main progress
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as e:
                    pass
                
                # Update counter
                with self.progress_lock:
                    self.videos_processed += 1
                    # Move cursor up and overwrite counter line
                    print(f"\033[{self.parallel_downloads + 1}A\r[{self.videos_processed}/{len(videos)}]" + " " * 20 + f"\033[{self.parallel_downloads + 1}B", end="")
    
    def _process_single_pdf(self, idx, total, title, url, local_dir, final_folder_id, final_dest_dir=None):
        """Process a single PDF download and optional upload/move"""
        print(f"\n   [{idx}/{total}] {title[:60]}...")
        
        safe_filename = self.sanitize_filename(title)
        
        # Check if already exists on Drive
        if not self.no_upload and final_folder_id and check_file_exists(self.drive_service, safe_filename + '.pdf', final_folder_id):
            print(f"      ⏭️  Already on Drive, skipping...")
            with self.stats_lock:
                self.stats['skipped'] += 1
            return
        
        # Check if already exists in final destination (for local-only mode)
        if self.no_upload and final_dest_dir:
            final_path = final_dest_dir / f"{safe_filename}.pdf"
            if final_path.exists():
                print(f"      ⏭️  Already exists in destination, skipping")
                with self.stats_lock:
                    self.stats['skipped'] += 1
                return
        
        # Download PDF to temp folder
        local_path = self.download_pdf(title, url, local_dir)
        
        if not local_path or not os.path.exists(local_path):
            print(f"      ❌ Download failed")
            return
        
        # Upload to Drive if not in local-only mode
        if not self.no_upload and final_folder_id:
            print(f"      ☁️  Uploading to Google Drive...")
            upload_id = upload_file(
                self.drive_service,
                local_path,
                final_folder_id,
                os.path.basename(local_path)
            )
            
            if upload_id:
                with self.stats_lock:
                    self.stats['uploaded'] += 1
                
                # Delete local file
                if not self.keep_local:
                    try:
                        os.remove(local_path)
                        print(f"      🗑️  Local file deleted")
                    except:
                        pass
            else:
                print(f"      ❌ Upload failed")
                with self.stats_lock:
                    self.stats['failed'] += 1
        else:
            # Local-only mode - move file to final destination
            if final_dest_dir:
                import shutil
                final_path = final_dest_dir / os.path.basename(local_path)
                
                # Retry move with delays (aria2c may still have file handle)
                for attempt in range(5):
                    try:
                        if attempt > 0:
                            time.sleep(1)  # Wait for aria2c to release
                        shutil.move(str(local_path), str(final_path))
                        print(f"      ✅ Moved to: {final_path}")
                        break
                    except PermissionError:
                        if attempt == 4:  # Last attempt
                            if final_path.exists():
                                print(f"      ✅ Already moved: {final_path}")
                            else:
                                print(f"      ⚠️  Move failed, file in temp folder")
                    except Exception as e:
                        print(f"      ⚠️  Move error: {e}")
                        break
            else:
                print(f"      ✅ Saved locally: {local_path}")
        
        time.sleep(0.1)
    
    def _process_pdfs_sequential(self, pdfs, local_dir, final_folder_id, final_dest_dir=None):
        """Process PDFs one at a time"""
        for idx, (title, url) in enumerate(pdfs, 1):
            self._process_single_pdf(idx, len(pdfs), title, url, local_dir, final_folder_id, final_dest_dir)
    
    def _process_pdfs_parallel(self, pdfs, local_dir, final_folder_id, final_dest_dir=None):
        """Process multiple PDFs in parallel"""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        
        with ThreadPoolExecutor(max_workers=self.parallel_downloads) as executor:
            futures = []
            for idx, (title, url) in enumerate(pdfs, 1):
                future = executor.submit(
                    self._process_single_pdf,
                    idx, len(pdfs), title, url, local_dir, final_folder_id, final_dest_dir
                )
                futures.append(future)
            
            # Wait for all to complete
            for future in as_completed(futures):
                try:
                    future.result()
                except Exception as e:
                    print(f"\n   ⚠️  Parallel PDF download error: {e}")
    
    def process_all_batches(self):
        """Process all Batch_*.txt files"""
        batch_files = sorted(Path('.').glob('Batch_*.txt'))
        
        if not batch_files:
            print("❌ No Batch_*.txt files found")
            return
        
        print(f"\n{'='*80}")
        print(f"Found {len(batch_files)} batch files:")
        for f in batch_files:
            print(f"  • {f.name}")
        print(f"{'='*80}")
        
        for batch_file in batch_files:
            self.process_batch(str(batch_file))
        
        self.print_summary()
    
    def print_summary(self):
        """Print final statistics"""
        print(f"\n\n{'='*80}")
        print(f"📊 FINAL SUMMARY")
        print(f"{'='*80}")
        print(f"  ✅ Downloaded:    {self.stats['downloaded']}")
        print(f"  ☁️  Uploaded:      {self.stats['uploaded']}")
        print(f"  ⏭️  Skipped:       {self.stats['skipped']}")
        print(f"  📤 Moved:         {self.stats['moved']}")
        print(f"  ❌ Failed:        {self.stats['failed']}")
        print(f"{'='*80}\n")

def main():
    parser = argparse.ArgumentParser(description='Download Utkarsh batch videos to Google Drive')
    parser.add_argument('--batch', help='Specific batch ID to process')
    parser.add_argument('--all', action='store_true', help='Process all batch files')
    parser.add_argument('--folder', help='Google Drive parent folder ID')
    parser.add_argument('--keep', action='store_true', help='Keep local files after upload')
    parser.add_argument('--no-upload', action='store_true', help='Download only to local disk (skip Google Drive)')
    parser.add_argument('--parallel', type=int, default=4, help='Number of parallel videos (default: 4)')
    parser.add_argument('--test-parse', action='store_true', help='Test parsing without downloading')
    
    args = parser.parse_args()
    
    downloader = BatchVideoDownloader(
        parent_folder_id=args.folder,
        keep_local=args.keep,
        no_upload=args.no_upload,
        parallel_downloads=args.parallel
    )
    
    if args.test_parse:
        print("🧪 TEST MODE: Parsing files only\n")
        batch_files = sorted(Path('.').glob('Batch_*.txt'))
        for f in batch_files:
            batch_id, sections = downloader.parse_batch_file_multisection(str(f))
            print()
        return
    
    if args.batch:
        file = f"Batch_{args.batch}.txt"
        if Path(file).exists():
            downloader.process_batch(file)
        else:
            print(f"❌ File not found: {file}")
    elif args.all:
        downloader.process_all_batches()
    else:
        print("❌ Please specify --batch ID or --all")
        print("   Example: python batch_video_downloader_v2.py --batch 19367 --folder YOUR_FOLDER_ID")

if __name__ == "__main__":
    main()
