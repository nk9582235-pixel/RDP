import os
from dotenv import load_dotenv

load_dotenv()

# Telegram Configuration
API_ID = int(os.getenv("API_ID", "22117815"))
API_HASH = os.getenv("API_HASH", "f78352d2ffdf2082f1d5a627ec1cf542")
BOT_TOKEN = os.getenv("BOT_TOKEN", "8291426122:AAGk1CDbxYoXumQA4DNtFZQONrOTJRf0zTA")

# Authorized Users (add your Telegram user ID here)
AUTHORIZED_USERS = [int(x) for x in os.getenv("AUTHORIZED_USERS", "").split(",") if x.strip()]

# Google Drive Configuration
GOOGLE_CREDENTIALS_FILE = os.getenv("GOOGLE_CREDENTIALS_FILE", "credentials.json")
GOOGLE_TOKEN_FILE = os.getenv("GOOGLE_TOKEN_FILE", "token.json")

# For Render deployment - base64 encoded credentials
GOOGLE_CREDENTIALS_B64 = os.getenv("GOOGLE_CREDENTIALS_B64", "")
GOOGLE_TOKEN_B64 = os.getenv("GOOGLE_TOKEN_B64", "")
