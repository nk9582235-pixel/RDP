import os
import io
import re
import json
import base64
import tempfile
from typing import Optional, List, Dict, Any, Tuple
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload

import config

SCOPES = ['https://www.googleapis.com/auth/drive.readonly']


def setup_credentials_from_env():
    """Setup credentials files from base64 environment variables (for Render)."""
    if config.GOOGLE_CREDENTIALS_B64 and not os.path.exists(config.GOOGLE_CREDENTIALS_FILE):
        creds_data = base64.b64decode(config.GOOGLE_CREDENTIALS_B64)
        with open(config.GOOGLE_CREDENTIALS_FILE, 'wb') as f:
            f.write(creds_data)
    
    if config.GOOGLE_TOKEN_B64 and not os.path.exists(config.GOOGLE_TOKEN_FILE):
        token_data = base64.b64decode(config.GOOGLE_TOKEN_B64)
        with open(config.GOOGLE_TOKEN_FILE, 'wb') as f:
            f.write(token_data)


def get_drive_service():
    """Authenticate and return Google Drive service."""
    setup_credentials_from_env()
    
    creds = None
    if os.path.exists(config.GOOGLE_TOKEN_FILE):
        creds = Credentials.from_authorized_user_file(config.GOOGLE_TOKEN_FILE, SCOPES)
    
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            if not os.path.exists(config.GOOGLE_CREDENTIALS_FILE):
                raise FileNotFoundError(
                    "credentials.json not found. Please add your Google OAuth credentials."
                )
            flow = InstalledAppFlow.from_client_secrets_file(
                config.GOOGLE_CREDENTIALS_FILE, SCOPES
            )
            creds = flow.run_local_server(port=0)
        
        with open(config.GOOGLE_TOKEN_FILE, 'w') as token:
            token.write(creds.to_json())
    
    return build('drive', 'v3', credentials=creds)


def extract_folder_id(url_or_id: str) -> str:
    """Extract folder ID from Google Drive URL or return as-is if already an ID."""
    # Pattern for Google Drive folder URLs
    patterns = [
        r'drive\.google\.com/drive/folders/([a-zA-Z0-9_-]+)',
        r'drive\.google\.com/drive/u/\d+/folders/([a-zA-Z0-9_-]+)',
        r'drive\.google\.com/folderview\?id=([a-zA-Z0-9_-]+)',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url_or_id)
        if match:
            return match.group(1)
    
    # Assume it's already a folder ID
    return url_or_id.strip()


def get_folder_name(service, folder_id: str) -> str:
    """Get folder name by ID."""
    try:
        folder = service.files().get(fileId=folder_id, fields='name').execute()
        return folder.get('name', 'Unknown')
    except Exception:
        return 'Unknown'


def list_folder_contents(
    service, 
    folder_id: str, 
    file_types: Optional[List[str]] = None
) -> List[Dict[str, Any]]:
    """List all files and subfolders in a folder."""
    query = f"'{folder_id}' in parents and trashed = false"
    
    results = []
    page_token = None
    
    while True:
        response = service.files().list(
            q=query,
            spaces='drive',
            fields='nextPageToken, files(id, name, mimeType, size)',
            pageToken=page_token,
            orderBy='name'
        ).execute()
        
        results.extend(response.get('files', []))
        page_token = response.get('nextPageToken')
        
        if not page_token:
            break
    
    return results


def is_folder(file_info: Dict[str, Any]) -> bool:
    """Check if a file is a folder."""
    return file_info.get('mimeType') == 'application/vnd.google-apps.folder'


def is_media_file(file_info: Dict[str, Any]) -> bool:
    """Check if a file is a media file (video, audio, image, document)."""
    mime_type = file_info.get('mimeType', '')
    
    media_types = [
        'video/',
        'audio/',
        'image/',
        'application/pdf',
        'application/zip',
        'application/x-rar',
        'application/x-7z-compressed',
    ]
    
    return any(mime_type.startswith(mt) for mt in media_types)


async def traverse_folder(
    service,
    folder_id: str,
    path: List[str] = None,
    root_name: str = None
) -> List[Tuple[Dict[str, Any], List[str]]]:
    """
    Recursively traverse a folder and return all media files with their paths.
    
    Returns:
        List of tuples: (file_info, folder_path)
        folder_path is list of folder names from root to parent
    """
    if path is None:
        path = []
    
    if root_name is None:
        root_name = get_folder_name(service, folder_id)
        path = [root_name]
    
    contents = list_folder_contents(service, folder_id)
    files_with_paths = []
    
    for item in contents:
        if is_folder(item):
            # Recursively traverse subfolders
            subfolder_files = await traverse_folder(
                service,
                item['id'],
                path + [item['name']],
                root_name
            )
            files_with_paths.extend(subfolder_files)
        elif is_media_file(item):
            files_with_paths.append((item, path.copy()))
    
    return files_with_paths


async def download_file(service, file_id: str, file_name: str, file_size: int = 0, progress_callback=None) -> str:
    """
    Download a file from Google Drive to a temporary location.
    
    Args:
        service: Google Drive service
        file_id: ID of the file to download
        file_name: Name of the file
        file_size: Size of file in bytes (for progress calculation)
        progress_callback: Optional async callback(current, total) for progress
    
    Returns:
        Path to the downloaded file
    """
    request = service.files().get_media(fileId=file_id)
    
    # Create temp file with original extension
    _, ext = os.path.splitext(file_name)
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=ext)
    temp_path = temp_file.name
    temp_file.close()
    
    with open(temp_path, 'wb') as f:
        downloader = MediaIoBaseDownload(f, request)
        done = False
        while not done:
            status, done = downloader.next_chunk()
            if progress_callback and status:
                progress = status.progress()
                current = int(progress * file_size) if file_size else 0
                await progress_callback(current, file_size)
    
    return temp_path


def format_file_size(size_bytes: int) -> str:
    """Format file size in human readable format."""
    if size_bytes < 1024:
        return f"{size_bytes} B"
    elif size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"
    elif size_bytes < 1024 * 1024 * 1024:
        return f"{size_bytes / (1024 * 1024):.1f} MB"
    else:
        return f"{size_bytes / (1024 * 1024 * 1024):.2f} GB"
