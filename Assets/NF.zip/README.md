# Google Drive to Telegram Uploader Bot

Upload files from Google Drive to Telegram channel with hierarchical folder-based captions.

## Features

- 📂 Recursive folder traversal
- 📝 Automatic caption with folder hierarchy (Batch/Subject/Topic)
- 🎬 Supports video, audio, images, and documents
- 📊 Progress tracking and statistics
- 🔒 User authorization support

## Setup

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Google Drive Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing
3. Enable Google Drive API
4. Create OAuth 2.0 credentials (Desktop app)
5. Download `credentials.json` and place in project folder

### 3. First Run (Local)

Run locally to complete Google OAuth:

```bash
python main.py
```

A browser window will open - authorize the app. This creates `token.json`.

### 4. Environment Variables

Create `.env` file or set in Render:

```env
API_ID=22117815
API_HASH=f78352d2ffdf2082f1d5a627ec1cf542
BOT_TOKEN=8291426122:AAGk1CDbxYoXumQA4DNtFZQONrOTJRf0zTA
AUTHORIZED_USERS=your_user_id
```

### 5. Deploy to Render

1. Push code to GitHub
2. Connect repo to Render
3. Create a **Background Worker** service
4. Add environment variables:
   - `API_ID`, `API_HASH`, `BOT_TOKEN`
   - `AUTHORIZED_USERS` (comma-separated user IDs)
   - `GOOGLE_CREDENTIALS_B64`: Base64 of credentials.json
   - `GOOGLE_TOKEN_B64`: Base64 of token.json

To base64 encode files:

```bash
# Windows PowerShell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("credentials.json"))
[Convert]::ToBase64String([IO.File]::ReadAllBytes("token.json"))
```

## Usage

1. Start the bot: Send `/start`
2. Enter channel: Send channel username or ID
3. Enter folder: Send Google Drive folder URL
4. Bot uploads all files with formatted captions

## Caption Format

```
Index: 001

Title: video_name

Topic: Kinematics
Subject: Mechanics
Batch: Physics Batch
Extracted By: AI Bots
```

## Commands

- `/start` - Start upload process
- `/cancel` - Cancel current operation
