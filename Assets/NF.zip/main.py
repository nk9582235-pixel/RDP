import os
import asyncio
import logging
from aiohttp import web
from telethon import TelegramClient, events
from telethon.sessions import StringSession

import config
import gdrive

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Web server port for Render
PORT = int(os.getenv("PORT", 8080))

# Conversation states
class UserState:
    IDLE = 0
    WAITING_CHANNEL = 1
    WAITING_FOLDER = 2
    UPLOADING = 3

# Store user states and data
user_states = {}
user_data = {}


def get_state(user_id):
    return user_states.get(user_id, UserState.IDLE)


def set_state(user_id, state):
    user_states[user_id] = state


def is_authorized(user_id):
    if not config.AUTHORIZED_USERS:
        return True
    return user_id in config.AUTHORIZED_USERS


# Initialize Telethon client as bot
bot = TelegramClient(
    StringSession(),  # In-memory session
    config.API_ID,
    config.API_HASH
)


def create_progress_bar(current, total, width=20):
    if total == 0:
        return "░" * width
    filled = int(width * current / total)
    empty = width - filled
    bar = "█" * filled + "░" * empty
    percent = (current / total) * 100
    return f"[{bar}] {percent:.1f}%"


def format_caption(file_name, folder_path, index):
    title = os.path.splitext(file_name)[0]
    batch = folder_path[0] if len(folder_path) >= 1 else "Unknown"
    topic = folder_path[-1] if len(folder_path) >= 1 else "Unknown"
    
    if len(folder_path) > 2:
        subject = " > ".join(folder_path[1:-1])
    elif len(folder_path) == 2:
        subject = folder_path[0]
    else:
        subject = "N/A"
    
    return f"""Index: {index:03d}

Title: {title}

Topic: {topic}
Subject: {subject}
Batch: {batch}
Extracted By: AI Bots"""


@bot.on(events.NewMessage(pattern='/start'))
async def start_handler(event):
    user_id = event.sender_id
    logger.info(f"Received /start from user {user_id}")
    
    if not is_authorized(user_id):
        await event.reply("❌ You are not authorized to use this bot.")
        return
    
    set_state(user_id, UserState.WAITING_CHANNEL)
    
    await event.reply(
        "👋 **Welcome to Google Drive Uploader Bot!**\n\n"
        "This bot uploads files from Google Drive to your Telegram channel.\n\n"
        "📢 **Step 1:** Send me the channel where you want to upload.\n\n"
        "You can send:\n"
        "• Channel username (e.g., `@mychannel`)\n"
        "• Channel link (e.g., `t.me/mychannel`)\n"
        "• Channel ID (e.g., `-1001234567890`)\n\n"
        "⚠️ Make sure the bot is an admin in the channel!"
    )


@bot.on(events.NewMessage(pattern='/cancel'))
async def cancel_handler(event):
    user_id = event.sender_id
    if get_state(user_id) != UserState.IDLE:
        set_state(user_id, UserState.IDLE)
        user_data.pop(user_id, None)
        await event.reply("❌ Operation cancelled. Send /start to begin again.")
    else:
        await event.reply("ℹ️ Nothing to cancel. Send /start to begin.")


@bot.on(events.NewMessage)
async def message_handler(event):
    # Skip commands
    if event.text and event.text.startswith('/'):
        return
    
    user_id = event.sender_id
    
    if not is_authorized(user_id):
        return
    
    state = get_state(user_id)
    
    if state == UserState.WAITING_CHANNEL:
        await handle_channel(event)
    elif state == UserState.WAITING_FOLDER:
        await handle_folder(event)
    elif state == UserState.UPLOADING:
        await event.reply("⏳ Upload in progress. Please wait or send /cancel to stop.")


async def handle_channel(event):
    import re
    user_id = event.sender_id
    text = event.text.strip()
    
    # Parse channel
    channel_id = text
    if 't.me/' in text:
        match = re.search(r't\.me/([a-zA-Z0-9_]+)', text)
        if match:
            channel_id = f"@{match.group(1)}"
    elif not text.startswith('@') and not text.lstrip('-').isdigit():
        channel_id = f"@{text}"
    
    try:
        # Convert to int if numeric
        if isinstance(channel_id, str) and channel_id.lstrip('-').isdigit():
            channel_id = int(channel_id)
        
        # Get channel info
        entity = await bot.get_entity(channel_id)
        
        user_data[user_id] = {
            'channel_id': entity.id,
            'channel_name': getattr(entity, 'title', str(entity.id))
        }
        
        set_state(user_id, UserState.WAITING_FOLDER)
        
        await event.reply(
            f"✅ Channel selected: **{user_data[user_id]['channel_name']}**\n\n"
            "📂 **Step 2:** Now send me the Google Drive folder URL.\n\n"
            "Example:\n"
            "`https://drive.google.com/drive/folders/xxxxx`"
        )
        
    except Exception as e:
        logger.error(f"Channel error: {e}")
        await event.reply(
            f"❌ Cannot access channel: {str(e)}\n\n"
            "Make sure:\n"
            "• The channel exists\n"
            "• The bot is added as an admin\n"
            "• You sent the correct ID/username"
        )


async def handle_folder(event):
    user_id = event.sender_id
    text = event.text.strip()
    
    if 'drive.google.com' not in text and len(text) < 20:
        await event.reply(
            "❌ Invalid Google Drive folder URL.\n\n"
            "Please send a valid folder URL like:\n"
            "`https://drive.google.com/drive/folders/xxxxx`"
        )
        return
    
    data = user_data.get(user_id, {})
    channel_id = data.get('channel_id')
    channel_name = data.get('channel_name', 'Unknown')
    
    if not channel_id:
        set_state(user_id, UserState.IDLE)
        await event.reply("❌ Session expired. Please send /start again.")
        return
    
    set_state(user_id, UserState.UPLOADING)
    
    status_msg = await event.reply(
        f"🚀 **Starting Upload**\n\n"
        f"📢 Channel: **{channel_name}**\n"
        f"🔄 Initializing..."
    )
    
    try:
        await upload_files(channel_id, text, status_msg, channel_name)
    except Exception as e:
        logger.error(f"Upload error: {e}")
        await status_msg.edit(f"❌ Upload failed: {str(e)}")
    finally:
        set_state(user_id, UserState.IDLE)
        user_data.pop(user_id, None)


async def upload_files(channel_id, folder_url, status_msg, folder_name_display):
    stats = {'total': 0, 'success': 0, 'failed': 0, 'skipped': 0}
    
    await status_msg.edit("🔄 Connecting to Google Drive...")
    service = gdrive.get_drive_service()
    
    folder_id = gdrive.extract_folder_id(folder_url)
    folder_name = gdrive.get_folder_name(service, folder_id)
    
    await status_msg.edit(f"📂 Scanning folder: **{folder_name}**\n\nThis may take a moment...")
    
    files_with_paths = await gdrive.traverse_folder(service, folder_id)
    stats['total'] = len(files_with_paths)
    
    if stats['total'] == 0:
        await status_msg.edit("❌ No media files found in the folder.")
        return stats
    
    await status_msg.edit(
        f"📂 Folder: **{folder_name}**\n"
        f"📁 Found: **{stats['total']}** files\n\n"
        f"⏳ Starting upload..."
    )
    
    for index, (file_info, folder_path) in enumerate(files_with_paths, 1):
        file_name = file_info['name']
        file_id = file_info['id']
        file_size = int(file_info.get('size', 0))
        
        # Skip files > 2GB
        if file_size > 2 * 1024 * 1024 * 1024:
            stats['skipped'] += 1
            continue
        
        try:
            # Download with progress updates
            last_update = [0]  # Use list for mutable reference in closure
            
            async def download_progress(current, total):
                now = asyncio.get_event_loop().time()
                if now - last_update[0] < 2:  # Throttle to 2 seconds
                    return
                last_update[0] = now
                progress_bar = create_progress_bar(current, total)
                try:
                    await status_msg.edit(
                        f"📂 Folder: **{folder_name}**\n"
                        f"📁 File: **{index}/{stats['total']}**\n\n"
                        f"⬇️ Downloading: `{file_name}`\n"
                        f"📦 Size: {gdrive.format_file_size(file_size)}\n\n"
                        f"{progress_bar}\n"
                        f"📊 {gdrive.format_file_size(current)} / {gdrive.format_file_size(total)}"
                    )
                except Exception:
                    pass
            
            # Download
            temp_path = await gdrive.download_file(service, file_id, file_name, file_size, download_progress)
            
            caption = format_caption(file_name, folder_path, index)
            
            # Upload with progress updates
            last_update[0] = 0
            
            def upload_progress(current, total):
                # Create async task to update message
                asyncio.create_task(update_upload_progress(current, total))
            
            async def update_upload_progress(current, total):
                nonlocal last_update
                now = asyncio.get_event_loop().time()
                if now - last_update[0] < 2:  # Throttle
                    return
                last_update[0] = now
                progress_bar = create_progress_bar(current, total)
                try:
                    await status_msg.edit(
                        f"📂 Folder: **{folder_name}**\n"
                        f"📁 File: **{index}/{stats['total']}**\n\n"
                        f"⬆️ Uploading: `{file_name}`\n"
                        f"📦 Size: {gdrive.format_file_size(file_size)}\n\n"
                        f"{progress_bar}\n"
                        f"📊 {gdrive.format_file_size(current)} / {gdrive.format_file_size(total)}"
                    )
                except Exception:
                    pass
            
            # Upload with Telethon (supports up to 2GB)
            await bot.send_file(
                channel_id,
                temp_path,
                caption=caption,
                force_document=False,
                supports_streaming=True,
                progress_callback=upload_progress
            )
            
            stats['success'] += 1
            
            # Cleanup
            if os.path.exists(temp_path):
                os.remove(temp_path)
                
        except Exception as e:
            logger.error(f"Error processing {file_name}: {e}")
            stats['failed'] += 1
    
    await status_msg.edit(
        f"✅ **Upload Complete!**\n\n"
        f"📂 Folder: **{folder_name}**\n"
        f"📊 **Statistics:**\n"
        f"├ Total: {stats['total']}\n"
        f"├ Success: {stats['success']}\n"
        f"├ Failed: {stats['failed']}\n"
        f"└ Skipped: {stats['skipped']}"
    )
    
    return stats


# Web server
async def health_check(request):
    return web.Response(text="Bot is running!")


async def run_web_server():
    app = web.Application()
    app.router.add_get("/", health_check)
    app.router.add_get("/health", health_check)
    
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, "0.0.0.0", PORT)
    await site.start()
    logger.info(f"🌐 Web server running on port {PORT}")


async def main():
    logger.info("🤖 Starting Google Drive Uploader Bot...")
    
    # Start web server
    await run_web_server()
    
    # Start bot
    await bot.start(bot_token=config.BOT_TOKEN)
    logger.info("✅ Bot is running!")
    
    # Keep running
    await bot.run_until_disconnected()


if __name__ == "__main__":
    asyncio.run(main())
