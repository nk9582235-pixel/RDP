import os
import asyncio
import logging
import threading
from aiohttp import web
from pyrogram import Client, filters, idle
from pyrogram.types import Message
import config
import gdrive
import uploader

# Setup logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Web server port
PORT = int(os.getenv("PORT", 9005))

# Initialize Pyrogram Client
app = Client(
    "gdrive_uploader_bot",
    api_id=config.API_ID,
    api_hash=config.API_HASH,
    bot_token=config.BOT_TOKEN,
    in_memory=True
)

# User States
class UserState:
    IDLE = 0
    WAITING_CHANNEL = 1
    WAITING_FOLDER = 2
    UPLOADING = 3

user_states = {}
user_data = {}
user_locks = {} # High-1: Concurrency Lock

def is_authorized(user_id):
    # Bug #8 Fix: Explicit check. If config is empty/None -> Public.
    if not config.AUTHORIZED_USERS:
        return True
    return user_id in config.AUTHORIZED_USERS

@app.on_message(filters.command("start") & filters.private) # Critical-1 Fix
async def start_handler(client: Client, message: Message):
    user_id = message.from_user.id
    logger.info(f"Received /start from {user_id}")
    
    # Critical-2 Fix: Always reset state on /start
    user_states[user_id] = UserState.WAITING_CHANNEL
    user_data.pop(user_id, None)

    logger.info(f"Authorization check for user {user_id}, authorized_users: {config.AUTHORIZED_USERS}")
    if not is_authorized(user_id):
        logger.info(f"User {user_id} is not authorized")
        await message.reply("❌ Unauthorized.")
        return
    else:
        logger.info(f"User {user_id} is authorized")

    await message.reply(
        "👋 **Welcome!**\n\n"
        "✅ Bot is online and ready!\n\n"
        "Send me the **Channel ID** (e.g., `-100xxxx`) or **Username** where you want to upload."
    )

@app.on_message(filters.command("cancel"))
async def cancel_handler(client: Client, message: Message):
    user_id = message.from_user.id
    # Critical-2 & Medium-1 Fix: Hard reset
    user_states[user_id] = UserState.IDLE
    user_data.pop(user_id, None)
    await message.reply("❌ Cancelled. Send /start to begin again.")

@app.on_message(filters.text & ~filters.command(["start", "cancel"]))
async def message_handler(client: Client, message: Message):
    user_id = message.from_user.id
    
    if not is_authorized(user_id):
        return

    # High-1 Fix: Concurrency Lock
    if user_id not in user_locks:
        user_locks[user_id] = asyncio.Lock()
        
    async with user_locks[user_id]:
        state = user_states.get(user_id, UserState.IDLE)

        if state == UserState.WAITING_CHANNEL:
            chat_input = message.text.strip()
            # Critical-3 Fix: Explicit validation
            if not (chat_input.startswith("@") or chat_input.startswith("-100")):
                await message.reply("❌ Invalid Channel Identifier.\nMust start with `@` (username) or `-100` (ID).")
                return

            try:
                chat = await client.get_chat(chat_input)
                user_data[user_id] = {'channel_id': chat.id, 'channel_title': chat.title}
                user_states[user_id] = UserState.WAITING_FOLDER
                await message.reply(
                    f"✅ Selected: **{chat.title}**\n\n"
                    "📂 Now send the **Google Drive Folder URL**."
                )
            except Exception as e:
                await message.reply(f"❌ Invalid Channel: {e}")

        elif state == UserState.WAITING_FOLDER:
            url = message.text
            if "drive.google.com" not in url:
                await message.reply("❌ Invalid Link.")
                return
                
            user_states[user_id] = UserState.UPLOADING
            status_msg = await message.reply("🔄 Connecting...")
            
            try:
                await uploader.upload_files_from_drive(
                    client, 
                    user_data[user_id]['channel_id'], 
                    url, 
                    status_msg
                )
            except Exception as e:
                await status_msg.edit(f"❌ Error: {e}")
                logger.error(f"Upload failed: {e}")
            finally:
                # Bug #7 Fix: Cleanup
                user_states[user_id] = UserState.IDLE
                user_data.pop(user_id, None)

# Web Server
async def health_check(request):
    return web.Response(text="Bot is running")

def start_web_server_thread():
    """Run aiohttp web server in a separate thread."""
    async def _runner():
        try:
            app_web = web.Application()
            app_web.router.add_get("/", health_check)
            runner = web.AppRunner(app_web)
            await runner.setup()
            site = web.TCPSite(runner, "0.0.0.0", PORT)
            await site.start()
            logger.info(f"🌐 Web server running on port {PORT}")
            # High-2 Fix: Run indefinitely but clean
            while True:
                await asyncio.sleep(3600)
        except Exception as ex:
            logger.error(f"Web server thread failed: {ex}")

    # Create a new event loop for this thread
    import asyncio
    try:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(_runner())
    except Exception as e:
        logger.error(f"Event loop error: {e}")
    finally:
        try:
            loop.close()
        except:
            pass

if __name__ == "__main__":
    logger.info("🤖 Starting Bot...")
    
    # Start web server in background thread
    try:
        t = threading.Thread(target=start_web_server_thread, daemon=True)
        t.start()
    except Exception as e:
        logger.error(f"Failed to start web server thread: {e}")
    
    # Run Pyrogram bot on main thread
    logger.info("✅ Bot Started! (Pyrogram)")
    try:
        app.run()
    except Exception as e:
        logger.critical(f"❌ Bot crashed: {e}", exc_info=True)
