import os
import time
from typing import List, Optional, Callable
from pyrogram import Client
from pyrogram.types import Message

import gdrive


def create_progress_bar(current: int, total: int, width: int = 20) -> str:
    """Create a text-based progress bar."""
    if total == 0:
        return "░" * width
    
    filled = int(width * current / total)
    empty = width - filled
    bar = "█" * filled + "░" * empty
    percent = (current / total) * 100
    return f"[{bar}] {percent:.1f}%"


def format_caption(
    file_name: str,
    folder_path: List[str],
    index: int
) -> str:
    """
    Format caption for uploaded file based on folder hierarchy.
    
    folder_path structure: [Batch, Subject1, Subject2, ..., Topic]
    - Batch: Root folder (first element)
    - Topic: Immediate parent folder (last element)  
    - Subject: Everything in between
    
    Example:
        folder_path = ["Physics Batch", "Mechanics", "Kinematics"]
        Batch = "Physics Batch"
        Subject = "Mechanics"
        Topic = "Kinematics"
    """
    # Remove file extension from name
    title = os.path.splitext(file_name)[0]
    
    # Get folder hierarchy parts
    batch = folder_path[0] if len(folder_path) >= 1 else "Unknown"
    topic = folder_path[-1] if len(folder_path) >= 1 else "Unknown"
    
    # Subject is everything between batch and topic
    if len(folder_path) > 2:
        subject = " > ".join(folder_path[1:-1])
    elif len(folder_path) == 2:
        subject = folder_path[0]  # Same as batch when only 2 levels
    else:
        subject = "N/A"
    
    caption = f"""Index: {index:03d}

Title: {title}

Topic: {topic}
Subject: {subject}
Batch: {batch}
Extracted By: AI Bots"""
    
    return caption


class ProgressTracker:
    """Track and update progress for download/upload operations."""
    
    def __init__(
        self, 
        status_message: Message, 
        folder_name: str,
        index: int,
        total_files: int,
        file_name: str,
        file_size: int,
        operation: str = "Downloading"
    ):
        self.status_message = status_message
        self.folder_name = folder_name
        self.index = index
        self.total_files = total_files
        self.file_name = file_name
        self.file_size = file_size
        self.operation = operation
        self.last_update = 0
        self.update_interval = 2  # Minimum seconds between updates
    
    async def update(self, current: int, total: int):
        """Update progress - throttled to avoid Telegram rate limits."""
        now = time.time()
        if now - self.last_update < self.update_interval:
            return
        
        self.last_update = now
        
        progress_bar = create_progress_bar(current, total)
        current_str = gdrive.format_file_size(current)
        total_str = gdrive.format_file_size(total)
        
        icon = "⬇️" if self.operation == "Downloading" else "⬆️"
        
        try:
            await self.status_message.edit_text(
                f"📂 Folder: **{self.folder_name}**\n"
                f"📁 Progress: **{self.index}/{self.total_files}**\n\n"
                f"{icon} {self.operation}: `{self.file_name}`\n"
                f"📦 Size: {total_str}\n\n"
                f"{progress_bar}\n"
                f"📊 {current_str} / {total_str}"
            )
        except Exception:
            pass  # Ignore update errors (rate limits, etc.)


async def upload_file(
    client: Client,
    chat_id,
    file_path: str,
    file_name: str,
    caption: str,
    progress_callback=None
) -> Optional[Message]:
    """
    Upload a file to Telegram channel.
    
    Automatically detects file type and uses appropriate upload method.
    """
    ext = os.path.splitext(file_name)[1].lower()
    
    # Determine file type based on extension
    video_exts = ['.mp4', '.mkv', '.avi', '.mov', '.webm', '.flv', '.wmv']
    audio_exts = ['.mp3', '.wav', '.flac', '.aac', '.ogg', '.m4a']
    image_exts = ['.jpg', '.jpeg', '.png', '.gif', '.webp', '.bmp']
    
    try:
        if ext in video_exts:
            message = await client.send_video(
                chat_id=chat_id,
                video=file_path,
                caption=caption,
                file_name=file_name,
                progress=progress_callback,
                supports_streaming=True
            )
        elif ext in audio_exts:
            message = await client.send_audio(
                chat_id=chat_id,
                audio=file_path,
                caption=caption,
                file_name=file_name,
                progress=progress_callback
            )
        elif ext in image_exts:
            message = await client.send_photo(
                chat_id=chat_id,
                photo=file_path,
                caption=caption,
                progress=progress_callback
            )
        else:
            # Send as document for all other file types
            message = await client.send_document(
                chat_id=chat_id,
                document=file_path,
                caption=caption,
                file_name=file_name,
                progress=progress_callback
            )
        
        return message
    
    except Exception as e:
        print(f"Error uploading {file_name}: {e}")
        return None


async def upload_files_from_drive(
    client: Client,
    chat_id,
    folder_url: str,
    status_message: Message
) -> dict:
    """
    Upload all files from a Google Drive folder to Telegram.
    
    Returns:
        Dictionary with upload statistics
    """
    stats = {
        'total': 0,
        'success': 0,
        'failed': 0,
        'skipped': 0
    }
    
    try:
        # Initialize Drive service
        await status_message.edit_text("🔄 Connecting to Google Drive...")
        service = gdrive.get_drive_service()
        
        # Extract folder ID
        folder_id = gdrive.extract_folder_id(folder_url)
        folder_name = gdrive.get_folder_name(service, folder_id)
        
        await status_message.edit_text(f"📂 Scanning folder: **{folder_name}**\n\nThis may take a moment...")
        
        # Get all files with paths
        files_with_paths = await gdrive.traverse_folder(service, folder_id)
        stats['total'] = len(files_with_paths)
        
        if stats['total'] == 0:
            await status_message.edit_text("❌ No media files found in the folder.")
            return stats
        
        await status_message.edit_text(
            f"📂 Folder: **{folder_name}**\n"
            f"📁 Found: **{stats['total']}** files\n\n"
            f"⏳ Starting upload..."
        )

        import json
        HISTORY_FILE = "history.json"

        # Load history
        uploaded_files = set()
        if os.path.exists(HISTORY_FILE):
            try:
                with open(HISTORY_FILE, 'r') as f:
                    uploaded_files = set(json.load(f))
            except Exception:
                pass

        # Function to save history atomic
        def save_history():
            import shutil
            try:
                temp_file = HISTORY_FILE + ".tmp"
                with open(temp_file, 'w') as f:
                    json.dump(list(uploaded_files), f)
                shutil.move(temp_file, HISTORY_FILE)
            except Exception:
                pass
        
        # Upload each file
        for index, (file_info, folder_path) in enumerate(files_with_paths, 1):
            file_name = file_info['name']
            file_id = file_info['id']
            file_size = int(file_info.get('size', 0))
            
            # Check if already uploaded
            if file_id in uploaded_files:
                stats['skipped'] += 1
                if index % 10 == 0:
                    await status_message.edit_text(
                        f"📂 Folder: **{folder_name}**\n"
                        f"⏩ Skipping previously uploaded files...\n"
                        f"✅ Processed: **{index}/{stats['total']}**"
                    )
                continue

            # Check file size (Telegram limit is ~2GB)
            if file_size > 2 * 1024 * 1024 * 1024:
                stats['skipped'] += 1
                continue
            
            try:
                # Create download progress tracker
                download_tracker = ProgressTracker(
                    status_message=status_message,
                    folder_name=folder_name,
                    index=index,
                    total_files=stats['total'],
                    file_name=file_name,
                    file_size=file_size,
                    operation="Downloading"
                )
                
                # Download file with progress
                temp_path = await gdrive.download_file(
                    service, 
                    file_id, 
                    file_name,
                    file_size=file_size,
                    progress_callback=download_tracker.update
                )
                
                # Format caption
                caption = format_caption(file_name, folder_path, index)
                
                # Create upload progress tracker
                upload_tracker = ProgressTracker(
                    status_message=status_message,
                    folder_name=folder_name,
                    index=index,
                    total_files=stats['total'],
                    file_name=file_name,
                    file_size=file_size,
                    operation="Uploading"
                )
                
                # Upload to Telegram with progress
                result = await upload_file(
                    client=client,
                    chat_id=chat_id,
                    file_path=temp_path,
                    file_name=file_name,
                    caption=caption,
                    progress_callback=upload_tracker.update
                )
                
                if result:
                    stats['success'] += 1
                    uploaded_files.add(file_id)
                    save_history()
                else:
                    stats['failed'] += 1
                
                # Cleanup temp file
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                    
            except Exception as e:
                print(f"Error processing {file_name}: {e}")
                stats['failed'] += 1
        
        # Final status
        await status_message.edit_text(
            f"✅ **Upload Complete!**\n\n"
            f"📂 Folder: **{folder_name}**\n"
            f"📊 **Statistics:**\n"
            f"├ Total: {stats['total']}\n"
            f"├ Success: {stats['success']}\n"
            f"├ Failed: {stats['failed']}\n"
            f"└ Skipped: {stats['skipped']}"
        )
        
    except Exception as e:
        await status_message.edit_text(f"❌ Error: {str(e)}")
        raise
    
    return stats
