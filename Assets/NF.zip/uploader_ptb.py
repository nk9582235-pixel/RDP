import os
import time
import tempfile
from typing import List
from telegram import Bot, Message

import gdrive


def create_progress_bar(current: int, total: int, width: int = 20) -> str:
    """Create a text-based progress bar."""
    if total == 0:
        return "░" * width
    filled = int(width * current / total)
    empty = width - filled
    bar = "█" * filled + "░" * empty
    percent = (current / total) * 100
    return f"[{bar}] {percent:.1f}%"


def format_caption(file_name: str, folder_path: List[str], index: int) -> str:
    """Format caption for uploaded file based on folder hierarchy."""
    title = os.path.splitext(file_name)[0]
    
    batch = folder_path[0] if len(folder_path) >= 1 else "Unknown"
    topic = folder_path[-1] if len(folder_path) >= 1 else "Unknown"
    
    if len(folder_path) > 2:
        subject = " > ".join(folder_path[1:-1])
    elif len(folder_path) == 2:
        subject = folder_path[0]
    else:
        subject = "N/A"
    
    caption = f"""Index: {index:03d}

Title: {title}

Topic: {topic}
Subject: {subject}
Batch: {batch}
Extracted By: AI Bots"""
    
    return caption


async def upload_files_from_drive(
    bot: Bot,
    chat_id: int,
    folder_url: str,
    status_message: Message
) -> dict:
    """Upload all files from Google Drive folder to Telegram."""
    stats = {'total': 0, 'success': 0, 'failed': 0, 'skipped': 0}
    
    try:
        await status_message.edit_text("🔄 Connecting to Google Drive...")
        service = gdrive.get_drive_service()
        
        folder_id = gdrive.extract_folder_id(folder_url)
        folder_name = gdrive.get_folder_name(service, folder_id)
        
        await status_message.edit_text(
            f"📂 Scanning folder: **{folder_name}**\n\nThis may take a moment...",
            parse_mode='Markdown'
        )
        
        files_with_paths = await gdrive.traverse_folder(service, folder_id)
        stats['total'] = len(files_with_paths)
        
        if stats['total'] == 0:
            await status_message.edit_text("❌ No media files found in the folder.")
            return stats
        
        await status_message.edit_text(
            f"📂 Folder: **{folder_name}**\n"
            f"📁 Found: **{stats['total']}** files\n\n"
            f"⏳ Starting upload...",
            parse_mode='Markdown'
        )
        
        for index, (file_info, folder_path) in enumerate(files_with_paths, 1):
            file_name = file_info['name']
            file_id = file_info['id']
            file_size = int(file_info.get('size', 0))
            
            # Bot API limit is 50MB for uploads
            if file_size > 50 * 1024 * 1024:
                print(f"⚠️ Skipping {file_name} - size {gdrive.format_file_size(file_size)} exceeds 50MB Bot API limit")
                stats['skipped'] += 1
                continue
            
            try:
                # Always show download status for each file
                progress_bar = create_progress_bar(index - 1, stats['total'])
                await status_message.edit_text(
                    f"📂 Folder: **{folder_name}**\n"
                    f"📁 Progress: **{index}/{stats['total']}**\n\n"
                    f"⬇️ Downloading: `{file_name}`\n"
                    f"📦 Size: {gdrive.format_file_size(file_size)}\n\n"
                    f"{progress_bar}",
                    parse_mode='Markdown'
                )
                
                # Download file
                temp_path = await gdrive.download_file(service, file_id, file_name, file_size)
                
                # Format caption
                caption = format_caption(file_name, folder_path, index)
                
                # Show upload status
                await status_message.edit_text(
                    f"📂 Folder: **{folder_name}**\n"
                    f"📁 Progress: **{index}/{stats['total']}**\n\n"
                    f"⬆️ Uploading: `{file_name}`\n"
                    f"📦 Size: {gdrive.format_file_size(file_size)}\n\n"
                    f"{progress_bar}",
                    parse_mode='Markdown'
                )
                
                # Upload based on file type
                ext = os.path.splitext(file_name)[1].lower()
                video_exts = ['.mp4', '.mkv', '.avi', '.mov', '.webm']
                audio_exts = ['.mp3', '.wav', '.flac', '.aac', '.m4a']
                image_exts = ['.jpg', '.jpeg', '.png', '.gif', '.webp']
                
                with open(temp_path, 'rb') as f:
                    if ext in video_exts:
                        await bot.send_video(chat_id=chat_id, video=f, caption=caption, filename=file_name)
                    elif ext in audio_exts:
                        await bot.send_audio(chat_id=chat_id, audio=f, caption=caption, filename=file_name)
                    elif ext in image_exts:
                        await bot.send_photo(chat_id=chat_id, photo=f, caption=caption)
                    else:
                        await bot.send_document(chat_id=chat_id, document=f, caption=caption, filename=file_name)
                
                stats['success'] += 1
                
                # Cleanup
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                    
            except Exception as e:
                print(f"Error processing {file_name}: {e}")
                stats['failed'] += 1
        
        await status_message.edit_text(
            f"✅ **Upload Complete!**\n\n"
            f"📂 Folder: **{folder_name}**\n"
            f"📊 **Statistics:**\n"
            f"├ Total: {stats['total']}\n"
            f"├ Success: {stats['success']}\n"
            f"├ Failed: {stats['failed']}\n"
            f"└ Skipped: {stats['skipped']}",
            parse_mode='Markdown'
        )
        
    except Exception as e:
        await status_message.edit_text(f"❌ Error: {str(e)}")
        raise
    
    return stats
